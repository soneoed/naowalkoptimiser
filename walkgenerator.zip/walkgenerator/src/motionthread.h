/** 
 */

#ifndef MOTIONTHREAD_H
#define MOTIONTHREAD_H

#include "walkgenerator.h"

void* runMotionThread(void* arg);

#endif

