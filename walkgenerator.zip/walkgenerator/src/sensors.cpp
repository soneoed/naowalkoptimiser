/** Sensor access functions and global variables
      - global store of arrays for feedback data
            * position, velocity, acceleration
            * current
            * stiffnesses and targets
            * temperatures
            * balance (accelerometers and gyros)
            * touch (all buttons + FSR)
            * battery (current, temp and voltage)
      - ALMemoryFastAccess is connected to the feedback data, and new data is copied to the global store
        
      - Feedback datalogging is also provided by this file
 * @author Jason Kulk
 * Version : $Id $
 
 * NUbots (c) 2008 All Rights Reserved
 */

#include "sensors.h"

// The current DCM time (ms) since object creation
int dcmTime = 0;
int dcmTimeSinceStart = 0;

// Proprioception Feedback Data. Velocities and Accelerations are measured by soft sensors
float jointPositions[J_NUM_JOINTS];
float jointVelocities[J_NUM_JOINTS];
float jointAccelerations[J_NUM_JOINTS];
float jointCurrents[J_NUM_JOINTS];
float jointTargets[J_NUM_JOINTS];
float jointHardnesses[J_NUM_JOINTS];

// Thermoception Feedback Data.
float jointTemperatures[J_NUM_JOINTS];

// Balance Feedback Data. Accelerometers and Gyros
float balanceValues[B_NUM_SENSORS];

// Touch Feedback Data. Foot Pressure sensors, foot bump sensors, and chest buttons
float touchValues[T_NUM_SENSORS];

// Battery Feedback Data. 
float batteryValues[E_NUM_SENSORS];

// Distance Feedback Data
float distanceValues[D_NUM_SENSORS];                // caution: these values are only to be used by me, use the sonic and infrared
float sonicValues[S_NUM_SENSORS];
float infraredValues[I_NUM_SENSORS];

// Index to AL string device names to be used with the stm
string indexToName[] = {string("head_yaw_position"), string("head_pitch_position"), string("l_shoulder_roll_position"), string("l_shoulder_pitch_position"), string("l_elbow_yaw_position"), string("l_elbow_roll_position"), string("r_shoulder_roll_position"), string("r_shoulder_pitch_position"), string("r_elbow_yaw_position"), string("r_elbow_roll_position"), string("l_hip_yawpitch_position"), string("l_hip_roll_position"), string("l_hip_pitch_position"), string("l_knee_pitch_position"), string("l_ankle_pitch_position"), string("l_ankle_roll_position"), string("r_hip_yawpitch_position"), string("r_hip_roll_position"), string("r_hip_pitch_position"), string("r_knee_pitch_position"), string("r_ankle_pitch_position"), string("r_ankle_roll_position")};
string indexToPositionSensor[] = {DN_HEAD_YAW_POSITION, DN_HEAD_PITCH_POSITION, DN_L_SHOULDER_ROLL_POSITION, DN_L_SHOULDER_PITCH_POSITION, DN_L_ELBOW_YAW_POSITION, DN_L_ELBOW_ROLL_POSITION, DN_R_SHOULDER_ROLL_POSITION, DN_R_SHOULDER_PITCH_POSITION, DN_R_ELBOW_YAW_POSITION, DN_R_ELBOW_ROLL_POSITION, DN_L_HIP_YAWPITCH_POSITION, DN_L_HIP_ROLL_POSITION, DN_L_HIP_PITCH_POSITION, DN_L_KNEE_PITCH_POSITION, DN_L_ANKLE_PITCH_POSITION, DN_L_ANKLE_ROLL_POSITION, DN_R_HIP_YAWPITCH_POSITION, DN_R_HIP_ROLL_POSITION, DN_R_HIP_PITCH_POSITION, DN_R_KNEE_PITCH_POSITION, DN_R_ANKLE_PITCH_POSITION, DN_R_ANKLE_ROLL_POSITION};
string indexToCurrentSensor[] = {DN_HEAD_YAW_CURRENT, DN_HEAD_PITCH_CURRENT, DN_L_SHOULDER_ROLL_CURRENT, DN_L_SHOULDER_PITCH_CURRENT, DN_L_ELBOW_YAW_CURRENT, DN_L_ELBOW_ROLL_CURRENT, DN_R_SHOULDER_ROLL_CURRENT, DN_R_SHOULDER_PITCH_CURRENT, DN_R_ELBOW_YAW_CURRENT, DN_R_ELBOW_ROLL_CURRENT, DN_L_HIP_YAWPITCH_CURRENT, DN_L_HIP_ROLL_CURRENT, DN_L_HIP_PITCH_CURRENT, DN_L_KNEE_PITCH_CURRENT, DN_L_ANKLE_PITCH_CURRENT, DN_L_ANKLE_ROLL_CURRENT, DN_R_HIP_YAWPITCH_CURRENT, DN_R_HIP_ROLL_CURRENT, DN_R_HIP_PITCH_CURRENT, DN_R_KNEE_PITCH_CURRENT, DN_R_ANKLE_PITCH_CURRENT, DN_R_ANKLE_ROLL_CURRENT};
string indexToTargetSensor[] = {DN_HEAD_YAW_TARGET, DN_HEAD_PITCH_TARGET, DN_L_SHOULDER_ROLL_TARGET, DN_L_SHOULDER_PITCH_TARGET, DN_L_ELBOW_YAW_TARGET, DN_L_ELBOW_ROLL_TARGET, DN_R_SHOULDER_ROLL_TARGET, DN_R_SHOULDER_PITCH_TARGET, DN_R_ELBOW_YAW_TARGET, DN_R_ELBOW_ROLL_TARGET, DN_L_HIP_YAWPITCH_TARGET, DN_L_HIP_ROLL_TARGET, DN_L_HIP_PITCH_TARGET, DN_L_KNEE_PITCH_TARGET, DN_L_ANKLE_PITCH_TARGET, DN_L_ANKLE_ROLL_TARGET, DN_R_HIP_YAWPITCH_TARGET, DN_R_HIP_ROLL_TARGET, DN_R_HIP_PITCH_TARGET, DN_R_KNEE_PITCH_TARGET, DN_R_ANKLE_PITCH_TARGET, DN_R_ANKLE_ROLL_TARGET};
string indexToHardnessSensor[] = {DN_HEAD_YAW_HARDNESS, DN_HEAD_PITCH_HARDNESS, DN_L_SHOULDER_ROLL_HARDNESS, DN_L_SHOULDER_PITCH_HARDNESS, DN_L_ELBOW_YAW_HARDNESS, DN_L_ELBOW_ROLL_HARDNESS, DN_R_SHOULDER_ROLL_HARDNESS, DN_R_SHOULDER_PITCH_HARDNESS, DN_R_ELBOW_YAW_HARDNESS, DN_R_ELBOW_ROLL_HARDNESS, DN_L_HIP_YAWPITCH_HARDNESS, DN_L_HIP_ROLL_HARDNESS, DN_L_HIP_PITCH_HARDNESS, DN_L_KNEE_PITCH_HARDNESS, DN_L_ANKLE_PITCH_HARDNESS, DN_L_ANKLE_ROLL_HARDNESS, DN_R_HIP_YAWPITCH_HARDNESS, DN_R_HIP_ROLL_HARDNESS, DN_R_HIP_PITCH_HARDNESS, DN_R_KNEE_PITCH_HARDNESS, DN_R_ANKLE_PITCH_HARDNESS, DN_R_ANKLE_ROLL_HARDNESS};
string indexToTemperatureSensor[] = {DN_HEAD_YAW_TEMPERATURE, DN_HEAD_PITCH_TEMPERATURE, DN_L_SHOULDER_ROLL_TEMPERATURE, DN_L_SHOULDER_PITCH_TEMPERATURE, DN_L_ELBOW_YAW_TEMPERATURE, DN_L_ELBOW_ROLL_TEMPERATURE, DN_R_SHOULDER_ROLL_TEMPERATURE, DN_R_SHOULDER_PITCH_TEMPERATURE, DN_R_ELBOW_YAW_TEMPERATURE, DN_R_ELBOW_ROLL_TEMPERATURE, DN_L_HIP_YAWPITCH_TEMPERATURE, DN_L_HIP_ROLL_TEMPERATURE, DN_L_HIP_PITCH_TEMPERATURE, DN_L_KNEE_PITCH_TEMPERATURE, DN_L_ANKLE_PITCH_TEMPERATURE, DN_L_ANKLE_ROLL_TEMPERATURE, DN_R_HIP_YAWPITCH_TEMPERATURE, DN_R_HIP_ROLL_TEMPERATURE, DN_R_HIP_PITCH_TEMPERATURE, DN_R_KNEE_PITCH_TEMPERATURE, DN_R_ANKLE_PITCH_TEMPERATURE, DN_R_ANKLE_ROLL_TEMPERATURE};
string indexToBalanceSensor[] = {DN_ACCEL_X, DN_ACCEL_Y, DN_ACCEL_Z, DN_ANGLE_X, DN_ANGLE_Y, DN_GYRO_X, DN_GYRO_Y};
string indexToTouchSensor[] = {DN_L_FSR_FL, DN_L_FSR_FR, DN_L_FSR_BL, DN_L_FSR_BR, DN_L_BUMP_L, DN_L_BUMP_R, DN_R_FSR_FL, DN_R_FSR_FR, DN_R_FSR_BL, DN_R_FSR_BR, DN_R_BUMP_L, DN_R_BUMP_R, DN_CHEST_BUTTON};
string indexToBatterySensor[] = {DN_CHARGE, DN_CURRENT, DN_VOLTAGE_MIN, DN_VOLTAGE_MAX, DN_TEMPERATURE};
string indexToDistanceSensor[] = {DN_US_DISTANCE};

/**************************************************************************************
Sensor Class Function Definitions
**************************************************************************************/
// Sensor Class Constructor
Sensors::Sensors(AL::ALPtr<AL::ALBroker> pBroker)
{
    jasonLog << "SENSORS: Constructing sensors" << endl;
    historyvelocityindex = 0;
    historybalanceindex = 0;
    jasonLog << "SENSORS: Initialising Time." << endl;
    dcmTime = (int)alDcm->call<int>("getTime",0);
    //dcmTime = alDcm->getTime(0);
    dcmStartTime = dcmTime;
    previousDcmTime = dcmStartTime;

    jasonLog << "SENSORS: Initialising feedback data" << endl;
    // Initialise sensory feedback arrays to be zero
    for (int i = 0; i < J_NUM_JOINTS; i++)
    {
        jointPositions[i] = 0;
        jointVelocities[i] = 0;
        jointAccelerations[i] = 0;
        previousJointPositions[i] = 0;
        previousJointVelocities[i] = 0;
        previousJointCurrents[i] = 0;
        for (int j = 0; j < VEL_WINDOW_SIZE; j++)
        {
            historyJointVelocities[i][j] = 0;
        }
    }
    
    // Initialise balance values (because they need to be filtered)
    for (int i=0; i < B_NUM_SENSORS; i++)
    {
        balanceValues[i] = 0;
        for (int j=0; j < B_WINDOW_SIZE; j++)
        {
            historyBalanceValues[i][j] = 0;
        }
    }
    
    // ALMemoryFastAccess connection to sensor data
    connectALMemoryFastAccess(pBroker);
    jasonLog << "SENSORS: Getting new sensor data for the first time." << endl;
    getSensorData();
   
   #if SENSOR_LOGGING > 0
      createLogs();                 // create logs only if that feature is enabled
   #endif
    
    jasonLog << "SENSORS: Finsihed constructing sensors" << endl;
    return;
}
// Sensor Class Destructor
Sensors::~Sensors()
{
   #if SENSOR_LOGGING > 0
      finishLogs();
   #endif
   return;
}

/*****************************************
 onNewSensorData()
 - gets lots of sensor data and copies it into organised arrays
 - triggers calculation of soft sensor values too
 - writes to files if datalogging is enabled
 *****************************************/
void Sensors::onNewSensorData()
{
   getSensorData();
   
#if SENSOR_LOGGING > 0
   writeSensorData();
#endif
   return;
}


/*****************************************
 getSensorData()
    - gets lots of sensor data and copies it
      into organised arrays
    - triggers calculation of soft sensor values too
*****************************************/
void Sensors::getSensorData()
{
    getTimeData();
    getFastMemData();
    
    signCurrentData();
    calculateJointVelocities();
    filterData();
    calculateJointAccelerations();

    updateSensorHistory();
    return;
}

/*****************************************
 writeSensorData()
    - writes the current sensor data into files
    - one file for each type of sensor data
*****************************************/
void Sensors::writeSensorData()
{
    writePositionData();
    writeVelocityData();
    writeAccelerationData();
    writeCurrentData();
    writeTargetData();
    writeHardnessData();
    writeTemperatureData();
    writeBalanceData();
    writeTouchData();
    writeBatteryData();
    writeDistanceData();
    return;
}

/*****************************************
 createLogs()
    - creates the sensor log files
*****************************************/
void Sensors::createLogs()
{
    positionLog.open("/var/log/jointPositions.csv", fstream::out);
    writeJointLabels(positionLog);
    velocityLog.open("/var/log/jointVelocities.csv", fstream::out);
    writeJointLabels(velocityLog);
    accelerationLog.open("/var/log/jointAccelerations.csv", fstream::out);
    writeJointLabels(accelerationLog);
    currentLog.open("/var/log/jointCurrents.csv", fstream::out);
    writeJointLabels(currentLog);
    targetLog.open("/var/log/jointTargets.csv", fstream::out);
    writeJointLabels(targetLog);
    hardnessLog.open("/var/log/jointHardnesses.csv", fstream::out);
    writeJointLabels(hardnessLog);
    temperatureLog.open("/var/log/jointTemperatures.csv", fstream::out);
    writeJointLabels(temperatureLog);
    balanceLog.open("/var/log/balanceValues.csv", fstream::out);
    writeBalanceLabels();
    touchLog.open("/var/log/touchValues.csv", fstream::out);
    writeTouchLabels();
    batteryLog.open("/var/log/batteryValues.csv", fstream::out);
    writeBatteryLabels();
    distanceLog.open("/var/log/distanceValues.csv", fstream::out);
    writeDistanceLabels();
}

/*****************************************
 finishLogs()
    - closes the sensor log files
*****************************************/
void Sensors::finishLogs()
{
    positionLog.close();
    velocityLog.close();
    accelerationLog.close();
    currentLog.close();
    targetLog.close();
    hardnessLog.close();
    temperatureLog.close();
    balanceLog.close();
    touchLog.close();
    batteryLog.close();
    distanceLog.close();
}

/*****************************************
 connectALMemoryFastAccess
    - connect all of the useful feedback data (position, current, target, temperature, balance, touch, battery) to the alFastMem
Preconditions: The module named "SensorDataGrabber" exists 
Postconditions: A connection to all of the feedback data is made 
*****************************************/
void Sensors::connectALMemoryFastAccess(AL::ALPtr<AL::ALBroker> pBroker)
{
    jasonLog << "SENSORS: Connecting to ALMemoryFastAccess." << endl;
    ALValue namelist;           // the list of names to be connected with alFastMem
    namelist.arrayReserve(ALL_NUM_SENSORS);
    
    // add position names
    for (int i=0; i<J_NUM_JOINTS; i++)
    {
        namelist.arrayPush(indexToPositionSensor[i]);
    }
    
    // add current names
    for (int i=0; i<J_NUM_JOINTS; i++)
    {
        namelist.arrayPush(indexToCurrentSensor[i]);
    }
    
    // add target names
    for (int i=0; i<J_NUM_JOINTS; i++)
    {
        namelist.arrayPush(indexToTargetSensor[i]);
    }
    
    // add hardness names
    for (int i=0; i<J_NUM_JOINTS; i++)
    {
        namelist.arrayPush(indexToHardnessSensor[i]);
    }
    
    // add temperature names
    for (int i=0; i<J_NUM_JOINTS; i++)
    {
        namelist.arrayPush(indexToTemperatureSensor[i]);
    }
    
    // add balance names
    for (int i=0; i<B_NUM_SENSORS; i++)
    {
        namelist.arrayPush(indexToBalanceSensor[i]);
    }
    
    // add touch names
    for (int i=0; i<T_NUM_SENSORS; i++)
    {
        namelist.arrayPush(indexToTouchSensor[i]);
    }
    
    // add battery names
    for (int i=0; i<E_NUM_SENSORS; i++)
    {
        namelist.arrayPush(indexToBatterySensor[i]);
    }
    
    // add distance names
    for (int i=0; i<D_NUM_SENSORS; i++)
    {
        namelist.arrayPush(indexToDistanceSensor[i]);
    }
    
    jasonLog << "SENSORS: Finished creating namelist for ALMemoryFastAccess" << endl;
    jasonLog << namelist.toString(AL::VerbosityMini) << endl;
    
    alFastMem->ConnectToVariables(pBroker, namelist);
    
    jasonLog << "SENSORS: Connection to ALMemoryFastAccess established." << endl;
    return;
}

/*****************************************
 get sensor data
*****************************************/
void Sensors::getTimeData()
{
  dcmTime = (int)alDcm->call<int>("getTime", 0);        // use THIS dcmTime when talking to the DCM
  dcmTimeSinceStart = abs(dcmStartTime - (int)alDcm->call<int>("getTime", 0));
  return;
}

/*****************************************
 getFastMemData()
    - all feedback data is now done through alFastMem
    - note the order in connectALMemoryFastAccess is the order used to extract the information
 Preconditions: the global store
 Postconiditions: the global store of feedback data is updated
*****************************************/
void Sensors::getFastMemData()
{
    vector<float> fastmemdata;
    alFastMem->GetValues(fastmemdata);
    
    // copy the new data into the global store. This takes negligible processing time. 

    unsigned int fastmemindex = 0;          // the present index into the alldata array
    
    // positions
    for (int i=0; i<J_NUM_JOINTS; i++)
    {
        jointPositions[i] = fastmemdata[fastmemindex];
        fastmemindex++;
    }
    
    // currents
    for (int i=0; i<J_NUM_JOINTS; i++)
    {
        jointCurrents[i] = fastmemdata[fastmemindex];
        fastmemindex++;
    }
    
    // targets
    for (int i=0; i<J_NUM_JOINTS; i++)
    {
        jointTargets[i] = fastmemdata[fastmemindex];
        fastmemindex++;
    }
    
    // hardnesses
    for (int i=0; i<J_NUM_JOINTS; i++)
    {
        jointHardnesses[i] = fastmemdata[fastmemindex];
        fastmemindex++;
    }
    
    // temperatures
    for (int i=0; i<J_NUM_JOINTS; i++)
    {
        jointTemperatures[i] = fastmemdata[fastmemindex];
        fastmemindex++;
    }
    
    // balance values
    for (int i=0; i<B_NUM_SENSORS; i++)
    {
        balanceValues[i] = fastmemdata[fastmemindex];
        fastmemindex++;
    }
    
    // touch values
    for (int i=0; i<T_NUM_SENSORS; i++)
    {
        touchValues[i] = fastmemdata[fastmemindex];
        fastmemindex++;
    }
    
    // battery values
    for (int i=0; i<E_NUM_SENSORS; i++)
    {
        batteryValues[i] = fastmemdata[fastmemindex];
        fastmemindex++;
    }
    
    // distance values
    for (int i=0; i<D_NUM_SENSORS; i++)
    {
        distanceValues[i] = fastmemdata[fastmemindex];
        fastmemindex++;
    }
    
    return;
}

/*****************************************
 Filter Data
 *****************************************/
void Sensors::filterData()
{
    filterBalanceValues();
    filterJointVelocities();
}

void Sensors::filterBalanceValues()
{
    // The balance values are filtered by a 8 order minimum phase FIR low pass filter. Passband edge = 6Hz, Passband ripple= 1dB, stopband edge -20dB.
    for (int i = 0; i < B_NUM_SENSORS; i++)
    {
        historyBalanceValues[i][historybalanceindex] = balanceValues[i];
        // DCM = 50Hz balanceValues[i] = 0.880663287116484*(-0.068828325795436*historyBalanceValues[i][(B_WINDOW_SIZE + historybalanceindex-8)%B_WINDOW_SIZE] - 0.066584108138720*historyBalanceValues[i][(B_WINDOW_SIZE + historybalanceindex-7)%B_WINDOW_SIZE] - 0.016367546372531*historyBalanceValues[i][(B_WINDOW_SIZE + historybalanceindex-6)%B_WINDOW_SIZE] + 0.099408189849786*historyBalanceValues[i][(B_WINDOW_SIZE + historybalanceindex-5)%B_WINDOW_SIZE] + 0.234571953457501*historyBalanceValues[i][(B_WINDOW_SIZE + historybalanceindex-4)%B_WINDOW_SIZE] + 0.318607970748508*historyBalanceValues[i][(B_WINDOW_SIZE + historybalanceindex-3)%B_WINDOW_SIZE] + 0.307674130346582*historyBalanceValues[i][(B_WINDOW_SIZE + historybalanceindex-2)%B_WINDOW_SIZE] + 0.216321829545804*historyBalanceValues[i][(B_WINDOW_SIZE + historybalanceindex-1)%B_WINDOW_SIZE] + 0.110703670369260*historyBalanceValues[i][historybalanceindex]);
        balanceValues[i] = 0.945625469066873*(-0.059311517098191*historyBalanceValues[i][(B_WINDOW_SIZE + historybalanceindex-8)%B_WINDOW_SIZE] - 0.000856137299458*historyBalanceValues[i][(B_WINDOW_SIZE + historybalanceindex-7)%B_WINDOW_SIZE] + 0.051964222917671*historyBalanceValues[i][(B_WINDOW_SIZE + historybalanceindex-6)%B_WINDOW_SIZE] + 0.127834095351578*historyBalanceValues[i][(B_WINDOW_SIZE + historybalanceindex-5)%B_WINDOW_SIZE] + 0.198715956886153*historyBalanceValues[i][(B_WINDOW_SIZE + historybalanceindex-4)%B_WINDOW_SIZE] + 0.235169385734816*historyBalanceValues[i][(B_WINDOW_SIZE + historybalanceindex-3)%B_WINDOW_SIZE] + 0.222053635052465*historyBalanceValues[i][(B_WINDOW_SIZE + historybalanceindex-2)%B_WINDOW_SIZE] + 0.166603220105332*historyBalanceValues[i][(B_WINDOW_SIZE + historybalanceindex-1)%B_WINDOW_SIZE] + 0.115328266134171*historyBalanceValues[i][historybalanceindex]);
    }
    historybalanceindex = (historybalanceindex + 1)%B_WINDOW_SIZE;
    return;
}

void Sensors::filterJointVelocities()
{
    // The velocity values are filtered by a 8 order minimum phase FIR low pass filter. Passband edge = 10Hz, Passband ripple= 1dB, stopband edge -20dB.
    /*for (int i = 0; i < J_NUM_JOINTS; i++)
    {
        historyJointVelocities[i][historyvelocityindex] = jointVelocities[i];
        //DCM = 50Hz jointVelocities[i] = 0.908471624011480*(0.027275582417591*historyJointVelocities[i][(VEL_WINDOW_SIZE + historyvelocityindex-8)%VEL_WINDOW_SIZE] + 0.075358585052493*historyJointVelocities[i][(VEL_WINDOW_SIZE + historyvelocityindex-7)%VEL_WINDOW_SIZE] + 0.140358120634960*historyJointVelocities[i][(VEL_WINDOW_SIZE + historyvelocityindex-6)%VEL_WINDOW_SIZE] + 0.197351021127837*historyJointVelocities[i][(VEL_WINDOW_SIZE + historyvelocityindex-5)%VEL_WINDOW_SIZE] + 0.220063227285465*historyJointVelocities[i][(VEL_WINDOW_SIZE + historyvelocityindex-4)%VEL_WINDOW_SIZE] + 0.197351021127837*historyJointVelocities[i][(VEL_WINDOW_SIZE + historyvelocityindex-3)%VEL_WINDOW_SIZE] + 0.140358120634960*historyJointVelocities[i][(VEL_WINDOW_SIZE + historyvelocityindex-2)%VEL_WINDOW_SIZE] + 0.075358585052493*historyJointVelocities[i][(VEL_WINDOW_SIZE + historyvelocityindex-1)%VEL_WINDOW_SIZE] + 0.027275582417591*historyJointVelocities[i][historyvelocityindex]);
        jointVelocities[i] = -0.059885673555845*historyJointVelocities[i][(VEL_WINDOW_SIZE + historyvelocityindex-8)%VEL_WINDOW_SIZE] - 0.101746769741238*historyJointVelocities[i][(VEL_WINDOW_SIZE + historyvelocityindex-7)%VEL_WINDOW_SIZE] - 0.026932512852181*historyJointVelocities[i][(VEL_WINDOW_SIZE + historyvelocityindex-6)%VEL_WINDOW_SIZE] + 0.043017527360489*historyJointVelocities[i][(VEL_WINDOW_SIZE + historyvelocityindex-5)%VEL_WINDOW_SIZE] + 0.185076072459385*historyJointVelocities[i][(VEL_WINDOW_SIZE + historyvelocityindex-4)%VEL_WINDOW_SIZE] + 0.264641510204521*historyJointVelocities[i][(VEL_WINDOW_SIZE + historyvelocityindex-3)%VEL_WINDOW_SIZE] + 0.286307728191018*historyJointVelocities[i][(VEL_WINDOW_SIZE + historyvelocityindex-2)%VEL_WINDOW_SIZE] + 0.215337183024144*historyJointVelocities[i][(VEL_WINDOW_SIZE + historyvelocityindex-1)%VEL_WINDOW_SIZE] + 0.136683810811822*historyJointVelocities[i][historyvelocityindex];
    }
    historyvelocityindex = (historyvelocityindex + 1)%VEL_WINDOW_SIZE;
    */
    double sum = 0;
    for (int jnum = 0; jnum < J_NUM_JOINTS; jnum++)
    {
        historyJointVelocities[jnum][historyvelocityindex] = jointVelocities[jnum];          // copy the joint velocity into the average buffer before it is filtered
        
        sum = 0;
        for (int i = 0; i < VEL_WINDOW_SIZE; i++)
        {
            sum += historyJointVelocities[jnum][i];
        }
        
        jointVelocities[jnum] = sum/VEL_WINDOW_SIZE;                                   // now set the jointVelocity to the averaged value
    }
    historyvelocityindex = (historyvelocityindex + 1)%VEL_WINDOW_SIZE;
    return;
}

/*****************************************
 calculate soft sensor data
*****************************************/


/* Signs the electric current data
 Preconditions: jointTargets, jointPositions and jointCurrents must have been set
 */
void Sensors::signCurrentData()
{
    for (int i=0; i< J_NUM_JOINTS; i++)
    {
        if (jointHardnesses[i] <= 0)                // if the motor hardness is off keep the current sign the same as the previous value
        {
            if (previousJointCurrents[i] < 0)
                jointCurrents[i] = -jointCurrents[i];
        }
        else if (jointTargets[i] < jointPositions[i])
            jointCurrents[i] = -jointCurrents[i];
    }
    return;
}

void Sensors::calculateJointVelocities()
{
    if (dcmTime - previousDcmTime < 5)                // don't try and calculate the velocities; this avoids divide by zero errors
    {
        return;
    }
    
    for (int i=0; i<J_NUM_JOINTS; i++)
    {
        jointVelocities[i] = 1000*(jointPositions[i] - previousJointPositions[i])/(dcmTime - previousDcmTime);
    }
    return;
}

void Sensors::calculateJointAccelerations()
{
   if (dcmTime - previousDcmTime < 5)                // don't try and calculate the acceleration
   {
      return;
   }

   for (int i = 0; i < J_NUM_JOINTS; i++)
   {
    jointAccelerations[i] = 1000*(jointVelocities[i] - previousJointVelocities[i])/(dcmTime - previousDcmTime);
   }
   return;
}

void Sensors::updateSensorHistory()
{
    previousDcmTime = dcmTime;
    for (int i = 0; i < J_NUM_JOINTS; i++)
    {
        previousJointPositions[i] = jointPositions[i];
        previousJointVelocities[i] = jointVelocities[i];
        previousJointCurrents[i] = jointCurrents[i];
    }
    return;
}


/*****************************************
 write sensor data
*****************************************/
void Sensors::writePositionData()
{
  // Time
  positionLog << dcmTimeSinceStart << ", ";
  for (int i = 0; i < J_NUM_JOINTS; i++)
  {
    positionLog << jointPositions[i] << ", ";
  }
  positionLog << endl;
  return;
}

void Sensors::writeVelocityData()
{
  // Time
  velocityLog << dcmTimeSinceStart << ", ";
  for (int i = 0; i < J_NUM_JOINTS; i++)
  {
    velocityLog << jointVelocities[i] << ", ";
  }
  velocityLog << endl;
  return;
}

void Sensors::writeAccelerationData()
{
  // Time
  accelerationLog << dcmTimeSinceStart << ", ";
  for (int i = 0; i < J_NUM_JOINTS; i++)
  {
    accelerationLog << jointAccelerations[i] << ", ";
  }
  accelerationLog << endl;
  return;
}

void Sensors::writeCurrentData()
{
  // Time
  currentLog << dcmTimeSinceStart << ", ";
  for (int i = 0; i < J_NUM_JOINTS; i++)
  {
    currentLog << jointCurrents[i] << ", ";
  }
  currentLog << endl;
  return;
}

void Sensors::writeTargetData()
{
  targetLog << dcmTimeSinceStart << ", ";
  for (int i = 0; i < J_NUM_JOINTS; i++)
  {
    targetLog << jointTargets[i] << ", ";
  }
  targetLog << endl;
  return;
}

void Sensors::writeHardnessData()
{
    hardnessLog << dcmTimeSinceStart << ", ";
    for (int i = 0; i < J_NUM_JOINTS; i++)
    {
        hardnessLog << jointHardnesses[i] << ", ";
    }
    hardnessLog << endl;
    return;
}

void Sensors::writeBalanceData()
{
  balanceLog << dcmTimeSinceStart << ", ";
  for (int i = 0; i < B_NUM_SENSORS; i++)
  {
    balanceLog << balanceValues[i] << ", ";
  }
  balanceLog << endl; 
  return;
}

void Sensors::writeTouchData()
{
  touchLog << dcmTimeSinceStart << ", ";
  for (int i = 0; i < T_NUM_SENSORS; i++)
  {
    touchLog << touchValues[i] << ", ";
  }
  touchLog << endl; 
  return;
}

void Sensors::writeTemperatureData()
{
  temperatureLog << dcmTimeSinceStart << ", ";
  for (int i = 0; i < J_NUM_JOINTS; i++)
  {
    temperatureLog << jointTemperatures[i] << ", ";
  }
  temperatureLog << endl;
  return;
}

void Sensors::writeBatteryData()
{
  batteryLog << dcmTimeSinceStart << ", ";
  for (int i = 0; i < E_NUM_SENSORS; i++)
  {
    batteryLog << batteryValues[i] << ", ";
  }
  batteryLog << endl;
  return;
}

void Sensors::writeDistanceData()
{
    distanceLog << dcmTimeSinceStart << ", ";
    for (int i = 0; i < S_NUM_SENSORS; i++)
    {
        distanceLog << sonicValues[i] << ", ";
    }
    for (int i = 0; i < I_NUM_SENSORS; i++)
    {
        distanceLog << infraredValues[i] << ", ";
    }
    distanceLog << endl;
    return;
}

void Sensors::writeJointLabels(ofstream &logfile)
{    
    logfile << "Time (ms), ";
    logfile << "HEAD_YAW, ";
    logfile << "HEAD_PITCH, ";
    logfile << "L_SHOULDER_ROLL, ";
    logfile << "L_SHOULDER_PITCH, ";
    logfile << "L_ELBOW_YAW, ";
    logfile << "L_ELBOW_ROLL, ";
    logfile << "R_SHOULDER_ROLL, ";
    logfile << "R_SHOULDER_PITCH, ";
    logfile << "R_ELBOW_YAW, ";
    logfile << "R_ELBOW_ROLL, ";
    logfile << "L_HIP_YAW_PITCH, ";
    logfile << "L_HIP_ROLL, ";
    logfile << "L_HIP_PITCH, ";
    logfile << "L_KNEE_PITCH, ";
    logfile << "L_ANKLE_PITCH, ";
    logfile << "L_ANKLE_ROLL, ";
    logfile << "R_HIP_YAW_PITCH, ";
    logfile << "R_HIP_ROLL, ";
    logfile << "R_HIP_PITCH, ";
    logfile << "R_KNEE_PITCH, ";
    logfile << "R_ANKLE_PITCH, ";
    logfile << "R_ANKLE_ROLL, ";
    logfile << endl;
}

void Sensors::writeBalanceLabels()
{
    balanceLog << "Time (ms), ";
    balanceLog << "B_ACCEL_X, ";
    balanceLog << "B_ACCEL_Y, ";
    balanceLog << "B_ACCEL_Z, ";
    balanceLog << "B_ANGLE_X, ";
    balanceLog << "B_ANGLE_Y, ";
    balanceLog << "B_GYRO_X, ";
    balanceLog << "B_GYRO_Y, ";
    balanceLog << endl;
    return;
}

void Sensors::writeTouchLabels()
{
    touchLog << "Time (ms), ";
    touchLog << "T_L_FSR_FL, ";
    touchLog << "T_L_FSR_FR, ";
    touchLog << "T_L_FSR_BL, ";
    touchLog << "T_L_FSR_BR, ";
    touchLog << "T_L_BUMP_L, ";
    touchLog << "T_L_BUMP_R, ";
    touchLog << "T_R_FSR_FL, ";
    touchLog << "T_R_FSR_FR, ";
    touchLog << "T_R_FSR_BL, ";
    touchLog << "T_R_FSR_BR, ";
    touchLog << "T_R_BUMP_L, ";
    touchLog << "T_R_BUMP_R, ";
    touchLog << "T_CHEST_BUTTON, ";
    touchLog << endl;
    return;
}

void Sensors::writeBatteryLabels()
{
    batteryLog << "Time (ms), ";
    batteryLog << "E_CHARGE, ";
    batteryLog << "E_CURRENT, ";
    batteryLog << "E_VOLTAGE_MIN, ";
    batteryLog << "E_VOLTAGE_MAX, ";
    batteryLog << "E_TEMPERATURE, ";
    batteryLog << endl;
    return;
}

void Sensors::writeDistanceLabels()
{
    distanceLog << "Time (ms), ";
    distanceLog << "S_LL, ";
    distanceLog << "S_LR, ";
    distanceLog << "S_RL, ";
    distanceLog << "S_RR, ";
    distanceLog << "I_L, ";
    distanceLog << "I_R, ";
    distanceLog << endl;
    return;
}
  
