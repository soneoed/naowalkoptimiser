/*
*/

#include "containers.h"

// Common Helper functions
void writeJointLabels(stringstream &stream)
{
   stream << "L_SHOULDER_ROLL, ";
   stream << "L_SHOULDER_PITCH, ";
   stream << "L_ELBOW_YAW, ";
   stream << "L_ELBOW_ROLL, ";
   stream << "R_SHOULDER_ROLL, ";
   stream << "R_SHOULDER_PITCH, ";
   stream << "R_ELBOW_YAW, ";
   stream << "R_ELBOW_ROLL, ";
   stream << "L_HIP_YAW_PITCH, ";
   stream << "L_HIP_ROLL, ";
   stream << "L_HIP_PITCH, ";
   stream << "L_KNEE_PITCH, ";
   stream << "L_ANKLE_PITCH, ";
   stream << "L_ANKLE_ROLL, ";
   stream << "R_HIP_YAW_PITCH, ";
   stream << "R_HIP_ROLL, ";
   stream << "R_HIP_PITCH, ";
   stream << "R_KNEE_PITCH, ";
   stream << "R_ANKLE_PITCH, ";
   stream << "R_ANKLE_ROLL, ";
   stream << endl;
}

void writeJointValues(stringstream &stream, float jointvalues[])
{
   struct timespec starttime, endtime;
   float runtime;
   clock_gettime(CLOCK_REALTIME, &starttime);

   for (int i = 2; i < J_NUM_JOINTS; i++)                   // Modified so that I don't touch the head!
   {
      stream << jointvalues[i] << ", ";
   }
   stream << endl;
   
   clock_gettime(CLOCK_REALTIME, &endtime);
   runtime = (endtime.tv_nsec - starttime.tv_nsec)/1e6 + (endtime.tv_sec - starttime.tv_sec)*1e3;
   if (runtime > 0.5)
      jasonLog << "writeJointValues: Excessive runtime " << runtime << "ms." << endl;
   return;
}


/********************************************************************************************************************************************************
 Pose
********************************************************************************************************************************************************/
Pose::Pose(std::string name, float initialpose[J_NUM_JOINTS])
{
   #if CONTAINERS_DEBUG > 2
      jasonLog << "POSE: Creating new container for pose " << name << endl;
   #endif
   Name = name;
   for (unsigned char i=0; i<J_NUM_JOINTS; i++)
   {
      Targets[i] = initialpose[i];
   }
   
   // initialise the stringstream of data
   //stringstream ss(stringstream::out);
   writeJointLabels(ss);
   
   // write the data to the string stream
   writeJointValues(ss, initialpose);
}

Pose::~Pose()
{
}

void Pose::writeToFile()
{
   std::string filename = Name;
   // add directory to filename
   filename.insert(0,"/home/root/poses/Pose");
   filename.append("Start.csv");
   
#if CAPTURELOGIC_DEBUG > 1
   jasonLog << "POSE: Saving initial pose for primitive: " << Name << " to " << filename << endl;
#endif
   
   // open the file
   ofstream file;
   try
   {
      file.open(filename.c_str());
   }
   catch (ofstream::failure e)
   {
      jasonLog << "POSE: Unable to save pose. Could not open file" << endl;
   }
   
   // write the pose to the file
   file.write(ss.str().c_str(), ss.str().length());
   file.close();
}

/********************************************************************************************************************************************************
 Step
********************************************************************************************************************************************************/

Step::Step(std::string name)
{
   Name = name;
   
   // initialise the stringstream of data
   writeJointLabels(ss);
}

void Step::addData(float pose[J_NUM_JOINTS])
{
   float* newtargets = new float[J_NUM_JOINTS];
   for (unsigned char i=0; i<J_NUM_JOINTS; i++)
   {
      newtargets[i] = pose[i];
   }
   Targets.push_back(newtargets);
   writeJointValues(ss, pose);
}

void Step::writeToFile()
{
   std::string filename = Name;
   // add directory to filename
   filename.insert(0,"/home/root/steps/Position");
   filename.append(".csv");
   
#if CAPTURELOGIC_DEBUG > 1
   jasonLog << "STEP: Saving step " << Name << " to " << filename << endl;
#endif
   
   // open the file
   ofstream file;
   try
   {
      file.open(filename.c_str());
   }
   catch (ofstream::failure e)
   {
      jasonLog << "STEP: Unable to save pose. Could not open file" << endl;
   }
   
   // write the pose to the file
   file.write(ss.str().c_str(), ss.str().length());
   file.close();
}

Step::~Step()
{
}

/********************************************************************************************************************************************************
 PrimitiveContainer
********************************************************************************************************************************************************/
PrimitiveContainer::PrimitiveContainer(std::string primitivename)
{
   #if CONTAINERS_DEBUG > 1
      jasonLog << "PRIMITIVECONTAINER: Creating a new container for primitive: " << primitivename << endl;
   #endif
   Name = primitivename;
}

void PrimitiveContainer::addPose(float initialpose[J_NUM_JOINTS])
{
   #if CONTAINERS_DEBUG > 1
      jasonLog << "PRIMITIVECONTAINER: Adding the initial pose to " << Name << endl;
   #endif
   struct timespec starttime, endtime;
   float runtime;
   clock_gettime(CLOCK_REALTIME, &starttime);
   
   InitialPose = new Pose(Name, initialpose);
   
   clock_gettime(CLOCK_REALTIME, &endtime);
   runtime = (endtime.tv_nsec - starttime.tv_nsec)/1e6 + (endtime.tv_sec - starttime.tv_sec)*1e3;
   if (runtime > 0.5)
      jasonLog << "addPose: Excessive runtime " << runtime << "ms." << endl;
}

void PrimitiveContainer::addStep(std::string name)
{
   struct timespec starttime, endtime;
   float runtime;
   clock_gettime(CLOCK_REALTIME, &starttime);
   
   // name is already going to have 'Left' or 'Right' appended to it, so I need only add whether it is a starting step, and its step number
   if (Steps.size() == 0)      // if no previous steps then it this must be the first ;)
      name.append("Start");
   else if (Steps.size() == 1) // the following step is also special
      name.append("Follow");
   else                          // the remaining steps are all the same, so just label them based on their step number
   {                             // the step after the following step will be 0, as will the next step
      char temp[20];
      sprintf(temp, "%d", (Steps.size()-2)/2);      // using integer division to label left and right pairs with the same step number
      name.append(temp);
   }
   #if CONTAINERS_DEBUG > 1
      jasonLog << "PRIMITIVECONTAINER: Adding the step " << name << " to primitive " << Name << endl;
   #endif
   Steps.push_back(new Step(name));
   
   clock_gettime(CLOCK_REALTIME, &endtime);
   runtime = (endtime.tv_nsec - starttime.tv_nsec)/1e6 + (endtime.tv_sec - starttime.tv_sec)*1e3;
   if (runtime > 0.5)
      jasonLog << "addStep: Excessive runtime " << runtime << "ms." << endl;
}

void PrimitiveContainer::addToStep(float pose[J_NUM_JOINTS])
{
   #if CONTAINERS_DEBUG > 1
      jasonLog << "PRIMITIVECONTAINER: Adding to step" << endl;
   #endif
   
   struct timespec starttime, endtime;
   float runtime;
   clock_gettime(CLOCK_REALTIME, &starttime);
   
   Steps.back()->addData(pose);
   
   clock_gettime(CLOCK_REALTIME, &endtime);
   runtime = (endtime.tv_nsec - starttime.tv_nsec)/1e6 + (endtime.tv_sec - starttime.tv_sec)*1e3;
   if (runtime > 0.5)
      jasonLog << "addToStep: Excessive runtime " << runtime << "ms." << endl;
}

void PrimitiveContainer::finish()
{
   // Combine the last two steps to form the stopping step if and only if there are more than two steps in this primitive
   if (Steps.size() > 2)
      createStoppingStep();
   writeToFile();
}

void PrimitiveContainer::writeToFile()
{
   // Write the pose
   InitialPose->writeToFile();
   
   // Write each of the steps
   for (int i=0; i<Steps.size(); i++)
   {
      Steps[i]->writeToFile();
   }
}

void PrimitiveContainer::createStoppingStep()
{
   // My plan is to rename the second last step, and append all of the data in the last step to it. Then delete the last step :)
   #if CONTAINERS_DEBUG > 1
      jasonLog << "PRIMITIVECONTAINER: createStoppingStep() for " << Name << endl;
   #endif
   // Rename the second last step to be the stopping step
   Step* stoppingstep = Steps[Steps.size() - 2];
   size_t ffound = stoppingstep->Name.find("Follow");
   if (ffound != string::npos)
   {
      stoppingstep->Name.replace(stoppingstep->Name.size() - 6, 6, std::string("Stop"));
   }
   else
   {
      stoppingstep->Name.replace(stoppingstep->Name.size() - 1, 1, std::string("Stop"));        // replace the count with the word 'Stop'
   }
   #if CONTAINERS_DEBUG > 1
      jasonLog << "PRIMITIVECONTAINER: renamed second last step " << Steps[Steps.size() - 2]->Name << endl;
   #endif
   
   // Now add every entry in the last step to the second last step
   deque<float*> laststeptargets = Steps[Steps.size() - 1]->Targets;
   for (int i=0; i<laststeptargets.size(); i++)
   {
      stoppingstep->addData(laststeptargets[i]);
   }
   
   // Finally delete the last step, making the second last step the new stopping step
   Steps.pop_back();
   
}

PrimitiveContainer::~PrimitiveContainer()
{
   
}

