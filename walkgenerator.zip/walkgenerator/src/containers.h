/* Containers (Pose, Step, and WalkPrimitive) 
 I need to save the data and then write to files, so, I will organise the data into classes.
 */

#ifndef CONTAINERS_H
#define CONTAINERS_H

#include "walkgeneratormodule.h"

#define CONTAINERS_DEBUG       3

class Pose
{
public:
   Pose(std::string name, float initialpose[J_NUM_JOINTS]);
   ~Pose();
   void writeToFile();
public:
   std::string Name;
   float Targets[J_NUM_JOINTS];
private:
   stringstream ss;
};

class Step
{
public:
   Step(std::string name);
   ~Step();
   void addData(float pose[J_NUM_JOINTS]);
   void writeToFile();
public:
   std::string Name;             // I need this to determine what to call the file
   deque<float*> Targets;
private:
   stringstream ss;
};


class PrimitiveContainer
{
public:
   PrimitiveContainer(std::string primitivename);
   ~PrimitiveContainer();
   void addPose(float pose[J_NUM_JOINTS]);
   void addStep(std::string stepname);
   void addToStep(float pose[J_NUM_JOINTS]);
   void finish();
   
private:
   void createStoppingStep();
   void writeToFile();
   
public:
   std::string Name;             // I need this to determine what to call the steps
   Pose* InitialPose;            // Every primitive has an initial pose
   deque<Step*> Steps;                // A list of steps
};


#endif
