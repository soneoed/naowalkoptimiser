/* Walk and Pose Capture Logic
 Ok, this class contains the logic to capture gaits and poses using the Aldebaran walk engine
 This includes
 - finding the starting pose
 - capturing the starting step, making the left starting step (for straight, arc, and backward)
 - the stopping step is the mirror image of the starting step (need a left and right one too)
 - deciding left or right steps
 */

#include "capturelogic.h"
#include "walkgenerator.h"
#include "walkgeneratormodule.h"


CaptureLogic::CaptureLogic(WalkGeneratorModule* walkgenerator)
{
   #if CAPTURELOGIC_DEBUG > 1
      jasonLog << "CAPTURELOGIC: Constructing capture logic." << endl;
   #endif
   WalkGenerator = walkgenerator;
   
   resetCapture();
   GaitPrimitivePreviousName = GaitPrimitiveName;
   #if CAPTURELOGIC_DEBUG > 1
      jasonLog << "CAPTURELOGIC: Finished constructing capture logic." << endl;
   #endif
}

CaptureLogic::~CaptureLogic()
{
}

void CaptureLogic::doLogic()
{
   struct timespec starttime, endtime;
   float runtime;
   clock_gettime(CLOCK_REALTIME, &starttime);
   
   
   GaitPrimitiveName = WalkGenerator->getWalkPrimitiveName();
   GaitSubPrimitiveName = WalkGenerator->getWalkSubPrimitiveName();
   GaitSupportMode = alMotion->getSupportMode();
   
#if CAPTURELOGIC_DEBUG > 2
   jasonLog << "CAPTURELOGIC: Doing logic for " << GaitPrimitiveName << " in " << GaitSupportMode << endl;
#endif
   
   if (GaitPrimitiveName.compare(WALK_PRIMITIVE_FINISHED) == 0)
   {
      static bool finishedcalled = false;
      if (finishedcalled == false)
      {
         finishedcalled = true;
         #if CAPTURELOGIC_DEBUG > 1
            jasonLog << "CAPTURELOGIC: Finishing walk capture. Performing post capture calculations and writing logs" << endl;
         #endif
         for (int i=0; i<CapturedPrimitives.size(); i++)
            CapturedPrimitives[i]->finish();
      }
      return;
   }
   
   if (GaitPrimitiveName.compare(GaitPrimitivePreviousName) != 0 || GaitSubPrimitiveName.compare(GaitSubPrimitivePreviousName) != 0)
   {
      resetCapture();
      CapturedPrimitives.push_back(new PrimitiveContainer(GaitPrimitiveName + GaitSubPrimitiveName));
   }
   
   if (WalkGenerator->IsRunning)
   {
      if (PoseCapturing)
         doPoseCapturing();
      else if (GaitCapturing) 
      {
         if (GaitPrimitiveName.compare(WALK_PRIMITIVE_FORWARD) == 0)
         {
            #if CAPTURELOGIC_DEBUG > 3
               jasonLog << "CAPTURELOGIC: Running walk forward primitive capture." << endl;
            #endif
            doGaitCaptureA();
         }
         else if (GaitPrimitiveName.compare(WALK_PRIMITIVE_BACKWARD) == 0)
         {
            #if CAPTURELOGIC_DEBUG > 3
               jasonLog << "CAPTURELOGIC: Running walk backward primitive capture." << endl;
            #endif
            doGaitCaptureA();
         }
         else if (GaitPrimitiveName.compare(WALK_PRIMITIVE_ARC_LEFT) == 0)
         {
            #if CAPTURELOGIC_DEBUG > 3
               jasonLog << "CAPTURELOGIC: Running walk arc left primitive capture." << endl;
            #endif
            doGaitCaptureA();
         }
         else if (GaitPrimitiveName.compare(WALK_PRIMITIVE_ARC_RIGHT) == 0)
         {
            #if CAPTURELOGIC_DEBUG > 3
               jasonLog << "CAPTURELOGIC: Running walk arc right primitive capture." << endl;
            #endif
            doGaitCaptureA();
         }
         else if (GaitPrimitiveName.compare(WALK_PRIMITIVE_SIDEWARD_LEFT) == 0)
         {
            #if CAPTURELOGIC_DEBUG > 3
               jasonLog << "CAPTURELOGIC: Running walk sideward left primitive capture." << endl;
            #endif
            doGaitCaptureA();
         }
         else if (GaitPrimitiveName.compare(WALK_PRIMITIVE_SIDEWARD_RIGHT) == 0)
         {
            #if CAPTURELOGIC_DEBUG > 3
               jasonLog << "CAPTURELOGIC: Running walk sideward right primitive capture." << endl;
            #endif
            doGaitCaptureA();
         }
         else if (GaitPrimitiveName.compare(WALK_PRIMITIVE_TURN_LEFT) == 0)
         {
            #if CAPTURELOGIC_DEBUG > 3
               jasonLog << "CAPTURELOGIC: Running walk turn left primitive capture." << endl;
            #endif
            doGaitCaptureA();
         }
         else if (GaitPrimitiveName.compare(WALK_PRIMITIVE_TURN_RIGHT) == 0)
         {
            #if CAPTURELOGIC_DEBUG > 3
               jasonLog << "CAPTURELOGIC: Running walk turn right primitive capture." << endl;
            #endif
            doGaitCaptureA();
         }
         else
         {
            jasonLog << "CAPTURELOGIC: You are asking alMotion to generate a walk primitive it can't: " << GaitPrimitiveName << endl;
         }
      }
   }
   updateHistory();
   
   clock_gettime(CLOCK_REALTIME, &endtime);
   runtime = (endtime.tv_nsec - starttime.tv_nsec)/1e6 + (endtime.tv_sec - starttime.tv_sec)*1e3;
   if (runtime > 1)
      jasonLog << "doLogic: Excessive runtime " << runtime << "ms." << endl;
   return;
}

void CaptureLogic::doPoseCapturing()
{
   
   struct timespec starttime, endtime;
   float runtime;
   clock_gettime(CLOCK_REALTIME, &starttime);
   
   static int loopcount = 0;
   calculatePoseDerivatives();
   int numignore = 0;
   if (GaitPrimitiveName == WALK_PRIMITIVE_FORWARD)
      numignore = 10;
   else
      numignore = 2;
   if (loopcount > numignore)              // Ignore the first few because the joints probably haven't started moving yet!
   {
      if (PoseDerivativeSum < PoseMinimumDerivativeSum)
      {
         PoseMinimumDerivativeIndex = (HistoryTargetIndex + 1) % MAX_HISTORY_LENGTH;           // At this point in the execution the HistoryTargetIndex points to the most recent history, this pose will be the NEXT history entry
         PoseMinimumDerivativeSum = PoseDerivativeSum;
         #if CAPTURELOGIC_DEBUG > 2
            jasonLog << "CAPTURELOGIC: New minimum pose derivative sum: " << dcmTimeSinceStart << ", " << PoseDerivativeSum << endl;
         #endif
         for (int i=0; i < J_NUM_JOINTS; i++)
            PoseMinimumDerivativePose[i] = jointTargets[i];
      }
   }
   
   // if the support mode changes then we have gone past the initial pose, so save the best we have and move on
   if (GaitSupportMode != GaitPreviousSupportMode)
   {
      PoseCapturing = false;
      loopcount = 0;
      if (GaitSupportMode == alMotion->SUPPORT_MODE_DOUBLE_LEFT)        // gait ALWAYS starts from this support mode
      {
         PoseMinimumDerivativeIndex = (HistoryTargetIndex + 1) % MAX_HISTORY_LENGTH;           // At this point in the execution the HistoryTargetIndex points to the most recent history, this pose will be the NEXT history entry
         #if CAPTURELOGIC_DEBUG > 2
            jasonLog << "CAPTURELOGIC: Over-riding pose derivative min " << endl;
         #endif
         for (int i=0; i < J_NUM_JOINTS; i++)
            PoseMinimumDerivativePose[i] = jointTargets[i];
      }
         
      saveInitialPose();
      GaitCapturing = true;
   }
   loopcount++;
   
   clock_gettime(CLOCK_REALTIME, &endtime);
   runtime = (endtime.tv_nsec - starttime.tv_nsec)/1e6 + (endtime.tv_sec - starttime.tv_sec)*1e3;
   if (runtime > 1)
      jasonLog << "doPoseCapturing: Excessive runtime " << runtime << "ms." << endl;
}

void CaptureLogic::doGaitCaptureA()
{
   struct timespec starttime, endtime;
   float runtime;
   clock_gettime(CLOCK_REALTIME, &starttime);
   
   
   
   // Note that these are NOT setup as if else statements. This is so that the previous step can detect that its role has ended and the next one begins
   // in the same iteration
   if (GaitCapturingLeftStep == false && GaitCapturingRightStep == false)                    // with arc walking we need a starting and stopping step
      doStartingStepCapture();
   
   if (GaitCapturingLeftStep == true)
      doLeftStepCapture();
   
   if (GaitCapturingRightStep == true)
   {
      doRightStepCapture();
      if (GaitCapturingLeftStep == true)
         doLeftStepCapture();
   }
   
   clock_gettime(CLOCK_REALTIME, &endtime);
   runtime = (endtime.tv_nsec - starttime.tv_nsec)/1e6 + (endtime.tv_sec - starttime.tv_sec)*1e3;
   if (runtime > 1)
      jasonLog << "doGaitCaptureA: Excessive runtime " << runtime << "ms." << endl;
}

void CaptureLogic::doStartingStepCapture()
{
   static bool firstrun = true;
   #if CAPTURELOGIC_DEBUG > 2
      jasonLog << "CAPTURELOGIC: Doing starting step capture:" << dcmTimeSinceStart << endl;
   #endif
   
   if (firstrun == true)         // on the first run we need to back track to the 'PoseMinimumDerivativeIndex'
   {
      #if CAPTURELOGIC_DEBUG > 1
         jasonLog << "CAPTURELOGIC: Running walk primitive initial starting step capture." << endl;
      #endif
      firstrun = false;
      GaitCapturingStartingStep = true;
      
      // create, open and initialise the file where the starting step is going to be saved
      std::string name = GaitPrimitiveName + GaitSubPrimitiveName;
      
      // At this point in the capture process there is no way of conclusively knowing whether the first step is left or right
      // I have two choices, I can wait and see what the next support mode transition is, or I can hard code it based on the current walk primitive
      // The second option is probably better
      
      // All of these primitives always start with a right step
      if ((GaitPrimitiveName == WALK_PRIMITIVE_FORWARD) || (GaitPrimitiveName == WALK_PRIMITIVE_BACKWARD) || (GaitPrimitiveName == WALK_PRIMITIVE_ARC_RIGHT) || (GaitPrimitiveName == WALK_PRIMITIVE_SIDEWARD_RIGHT) || (GaitPrimitiveName == WALK_PRIMITIVE_TURN_RIGHT))
      {
         #if CAPTURELOGIC_DEBUG > 1
            jasonLog << "CAPTURELOGIC: Right starting step" << endl;
         #endif
         name.append("Right");
      }
      else     // the rest start with a left step
      {
         #if CAPTURELOGIC_DEBUG > 1
            jasonLog << "CAPTURELOGIC: Left starting step" << endl;
         #endif
         name.append("Left");
      }
      
      CapturedPrimitives.back()->addStep(name);
      
      #if CAPTURELOGIC_DEBUG > 2
            jasonLog << "CAPTURELOGIC: InitialPose index: " << PoseMinimumDerivativeIndex << " end search at: " << HistoryTargetIndex << endl;
      #endif
      
      if (PoseMinimumDerivativeIndex != HistoryTargetIndex)
      {
         // back track to the initial pose (ie. the start of the starting step), and save it to the file
         int i = (PoseMinimumDerivativeIndex + 1) % MAX_HISTORY_LENGTH;
         while (i != HistoryTargetIndex)
         {
            CapturedPrimitives.back()->addToStep(HistoryTargets[i]);
            i = (i + 1) % MAX_HISTORY_LENGTH;
         }
         CapturedPrimitives.back()->addToStep(HistoryTargets[HistoryTargetIndex]);       // write the most recent history entry too
      }
      CapturedPrimitives.back()->addToStep(jointTargets);
   }
   else
   {
      // The starting step ends when I reach SUPPORT_MODE_DOUBLE_LEFT or SUPPORT_MODE_DOUBLE_RIGHT
      if ((GaitSupportMode == alMotion->SUPPORT_MODE_DOUBLE_LEFT) && (GaitPreviousSupportMode == alMotion->SUPPORT_MODE_LEFT))
      {
         GaitCapturingStartingStep = false;
         GaitCapturingLeftStep = true;          // if we reach SUPPORT_MODE_DOUBLE_LEFT then we are about to step with left foot
         #if CAPTURELOGIC_DEBUG > 1
            jasonLog << "CAPTURELOGIC: Completed capturing RIGHT starting step: " << dcmTimeSinceStart << endl;
         #endif
         firstrun = true;
      }
      else if ((GaitSupportMode == alMotion->SUPPORT_MODE_DOUBLE_RIGHT) && (GaitPreviousSupportMode == alMotion->SUPPORT_MODE_RIGHT))
      {
         GaitCapturingStartingStep = false;
         GaitCapturingRightStep = true;          // if we reach 3 then we are about to step with right foot
         #if CAPTURELOGIC_DEBUG > 1
            jasonLog << "CAPTURELOGIC: Completed capturing LEFT starting step: " << dcmTimeSinceStart << endl;
         #endif
         firstrun = true;
      }
      else
         CapturedPrimitives.back()->addToStep(jointTargets);
   }
}

void CaptureLogic::doLeftStepCapture()
{
   #if CAPTURELOGIC_DEBUG > 2
      jasonLog << "CAPTURELOGIC: Doing left step capture:" << dcmTimeSinceStart << endl;
   #endif
   if (GaitNewLeftStep == true)
   {
      GaitNewLeftStep = false;
      std::string name = GaitPrimitiveName + GaitSubPrimitiveName;
      #if CAPTURELOGIC_DEBUG > 1
         jasonLog << "CAPTURELOGIC: Left step" << endl;
      #endif
      name.append("Left");
      CapturedPrimitives.back()->addStep(name);
   }
   
   if (GaitSupportMode == alMotion->SUPPORT_MODE_DOUBLE_RIGHT)
   {
      GaitCapturingLeftStep = false;
      GaitCapturingRightStep = true;
      GaitNewLeftStep = true;
      #if CAPTURELOGIC_DEBUG > 1
         jasonLog << "CAPTURELOGIC: Completed capturing LEFT STEP: " << dcmTimeSinceStart << endl;
      #endif
   }
   else
      CapturedPrimitives.back()->addToStep(jointTargets);
}

void CaptureLogic::doRightStepCapture()
{
   #if CAPTURELOGIC_DEBUG > 2
      jasonLog << "CAPTURELOGIC: Doing right step capture:" << dcmTimeSinceStart << endl;
   #endif
   if (GaitNewRightStep == true)
   {
      GaitNewRightStep = false;
      std::string name = GaitPrimitiveName + GaitSubPrimitiveName;
      
      #if CAPTURELOGIC_DEBUG > 1
         jasonLog << "CAPTURELOGIC: Right step" << endl;
      #endif
      name.append("Right");
      CapturedPrimitives.back()->addStep(name);
   }
   
   if (GaitSupportMode == alMotion->SUPPORT_MODE_DOUBLE_LEFT)
   {
      GaitCapturingRightStep = false;
      GaitCapturingLeftStep = true;
      GaitNewRightStep = true;
      #if CAPTURELOGIC_DEBUG > 1
         jasonLog << "CAPTURELOGIC: Completed capturing RIGHT STEP: " << dcmTimeSinceStart << endl;
      #endif
   }
   else
      CapturedPrimitives.back()->addToStep(jointTargets);
}

void CaptureLogic::calculatePoseDerivatives()
{
   PoseDerivativeSum = 0;
   for (int i=0; i < J_NUM_JOINTS; i++)
   {
      PoseDerivatives[i] = 50*(HistoryTargets[HistoryTargetIndex][i] - HistoryTargets[(MAX_HISTORY_LENGTH + HistoryTargetIndex - 1)%MAX_HISTORY_LENGTH][i]); 
      PoseDerivativeSum += fabs(PoseDerivatives[i]);
   }
}

void CaptureLogic::updateHistory()
{
   HistoryTargetIndex = (HistoryTargetIndex + 1) % MAX_HISTORY_LENGTH;
   for (int i=0; i < J_NUM_JOINTS; i++)
   {
      HistoryTargets[HistoryTargetIndex][i] = jointTargets[i];
   }
   GaitPrimitivePreviousName = GaitPrimitiveName;
   GaitSubPrimitivePreviousName = GaitSubPrimitiveName;
   GaitPreviousSupportMode = GaitSupportMode;
}

void CaptureLogic::resetCapture()
{
   #if CAPTURELOGIC_DEBUG > 1
      jasonLog << "CAPTURELOGIC: Reseting gait capture." << endl;
   #endif
   // Pose capture variables
   PoseCapturing = true;
   for (int i=0; i < J_NUM_JOINTS; i++)
   {
      PoseDerivatives[i] = 0;
   }
   PoseMinimumDerivativeSum = 1000;
   
   // Gait capture variables
   GaitPrimitiveName = WalkGenerator->getWalkPrimitiveName();
   GaitCapturing = false;
   GaitCapturingStartingStep = false;
   GaitCapturingLeftStep = false;
   GaitCapturingRightStep = false;
   GaitSupportMode = alMotion->getSupportMode();
   GaitNewRightStep = true;
   GaitNewLeftStep = true;
   
   // History
   HistoryTargetIndex = 0;
   for (int i=0; i < MAX_HISTORY_LENGTH; i++)
   {
      for (int j=0; j < J_NUM_JOINTS; j++)
      {
         HistoryTargets[i][j] = 0;
      }
   }
}

void CaptureLogic::saveInitialPose()
{
   CapturedPrimitives.back()->addPose(PoseMinimumDerivativePose);
}
