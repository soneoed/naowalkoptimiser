/**
 * @author Jason Kulk
 * NUbots (c) 2008 All Rights Reserved - This file is confidential.\n
 *
 * Version : $Id
 */

#include "motionthread.h"
#include "sensors.h"
#include "capturelogic.h"
#include "walkgeneratormodule.h"

using namespace std;

void* runGeneratorThread(void *arg)
{
   cout << "GENERATORTHREAD: Starting." << endl;
   
   WalkGeneratorModule* walkgenerator;
   walkgenerator = (WalkGeneratorModule*) arg;

   walkgenerator->run();
   
   pthread_exit(NULL);
}
