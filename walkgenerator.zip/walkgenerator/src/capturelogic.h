/* Walk and Pose Capture Logic
      Ok, this class contains the logic to capture gaits and poses using the Aldebaran walk engine
      This includes
         - finding the starting pose
         - capturing the starting step, making the left starting step (for straight, arc, and backward)
         - the stopping step is the mirror image of the starting step (need a left and right one too)
         - deciding left or right steps
 */

#ifndef CAPTURELOGIC_H
#define CAPTURELOGIC_H

#include "walkgeneratormodule.h"
#include "containers.h"

#define CAPTURELOGIC_DEBUG       3

#define MAX_HISTORY_LENGTH       300

class CaptureLogic
{
public:
   CaptureLogic(WalkGeneratorModule* walkgenerator);
   ~CaptureLogic();
   
   void doLogic();
   
private:
   void calculatePoseDerivatives();
   void updateHistory();
   void resetCapture();
   
   void doPoseCapturing();
   void saveInitialPose();
   
   void doGaitCaptureA();
   void doStartingStepCapture();
   void doLeftStepCapture();
   void doRightStepCapture();
   
private:
   // Walk Generator Module
   WalkGeneratorModule* WalkGenerator;
   
   // Captured Data Storage
   deque<PrimitiveContainer*> CapturedPrimitives;
   
   // Pose capture variables
   bool PoseCapturing;
   float PoseDerivatives[J_NUM_JOINTS];
   float PoseDerivativeSum;
   int PoseMinimumDerivativeIndex;
   float PoseMinimumDerivativeSum;
   float PoseMinimumDerivativePose[J_NUM_JOINTS];
   
   // Gait capture variables
   std::string GaitPrimitiveName, GaitPrimitivePreviousName;
   std::string GaitSubPrimitiveName, GaitSubPrimitivePreviousName;
   bool GaitCapturing;
   bool GaitCapturingStartingStep;
   bool GaitCapturingLeftStep;
   bool GaitCapturingRightStep;
   int GaitSupportMode, GaitPreviousSupportMode;
   bool GaitNewLeftStep, GaitNewRightStep;
   
   // History
   int HistoryTargetIndex;
   float HistoryTargets[MAX_HISTORY_LENGTH][J_NUM_JOINTS];
};



#endif

