/**
 * @author Jason Kulk
 * NUbots (c) 2008 All Rights Reserved - This file is confidential.\n
 *
 * Version : $Id
 */

#include "motionthread.h"
#include "sensors.h"
#include "capturelogic.h"
#include "walkgeneratormodule.h"

using namespace std;

void* runMotionThread(void *arg)
{
   jasonLog << "MOTIONTHREAD: Starting." << endl;
   sem_init(&semaphoreNewSensorData, 0, 0);    // it seems posting to an uninitialised semaphore is OK, so initialise it here
   jasonLog << "MOTIONTHREAD: Initialised semaphoreNewSensorData." << endl;

   WalkGeneratorModule* walkgenerator;
   walkgenerator = (WalkGeneratorModule*) arg;
   
   Sensors* sensors = new Sensors(walkgenerator->getParentBroker());
   CaptureLogic* logic = new CaptureLogic(walkgenerator);
   
   int err;
   struct timespec pretime, starttime, endtime;
   struct timespec relstarttime, relendtime;
   struct timespec prostarttime, proendtime;
   float runtime, waittime, relruntime, proruntime;       // the run time in ms
   do 
   {
      clock_gettime(CLOCK_REALTIME, &pretime);
      err = sem_wait(&semaphoreNewSensorData);
      clock_gettime(CLOCK_REALTIME, &starttime);
      clock_gettime(CLOCK_THREAD_CPUTIME_ID, &relstarttime);
      clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &prostarttime);
      waittime = (starttime.tv_nsec - pretime.tv_nsec)/1e6 + (starttime.tv_sec - pretime.tv_sec)*1e3;
      if (waittime > 25)
         jasonLog << "MOTIONTHREAD: Waittime " << waittime << " ms."<< endl;
      
      sensors->onNewSensorData();

      logic->doLogic();
      jasonLog << dcmTimeSinceStart << ", " << alMotion->getSupportMode() << endl;
      
      clock_gettime(CLOCK_REALTIME, &endtime);
      clock_gettime(CLOCK_THREAD_CPUTIME_ID, &relendtime);
      clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &proendtime);
      runtime = (endtime.tv_nsec - starttime.tv_nsec)/1e6 + (endtime.tv_sec - starttime.tv_sec)*1e3;
      relruntime = (relendtime.tv_nsec - relstarttime.tv_nsec)/1e6 + (relendtime.tv_sec - relstarttime.tv_sec)*1e3;
      proruntime = (proendtime.tv_nsec - prostarttime.tv_nsec)/1e6 + (proendtime.tv_sec - prostarttime.tv_sec)*1e3;
      if (runtime > 5)
      {
         jasonLog << "MOTIONTHREAD: Jason cycle time error: " << runtime << " ms. Time spent in this thread: " << relruntime << "ms, in this process: " << proruntime << endl;
      }
   } 
   while (err != EINTR);
   pthread_exit(NULL);
}
