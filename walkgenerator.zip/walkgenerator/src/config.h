/* -*- C++ -*- Tell editors this is a C++ file (despite it's .in extension) */
/* This is an auto generated file. Please do not edit it.*/

/**
 * @author Jason Kulk
 *
 * Version : $Id$
 */

#include "configcore.h"
#ifndef CONFIG_H
#define CONFIG_H

// .:: System Headers ::

// ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: Typedefs :::..

// ::::::::::::::::::::::::::::::::::::::::::::::::::::: Platform variables :::..

# define WALKGENERATOR_IS_REMOTE_OFF

# define WALKGENERATOR_REVISION ""

// :::::::::::::::::::::::::::::::::::::::::::::::::::::: Options variables :::..

#endif // !CONFIG_H

