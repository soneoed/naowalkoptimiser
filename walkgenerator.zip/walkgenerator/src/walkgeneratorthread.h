/** 
 */

#ifndef WALKGENERATORTHREAD_H
#define WALKGENERATORTHREAD_H

#include "walkgenerator.h"

void* runGeneratorThread(void* arg);

#endif

