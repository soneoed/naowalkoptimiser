""" 

Jason Kulk
"""
import csv, numpy, pylab, matplotlib, sys, glob

class StepMirror:
    """
    """
    
    def __init__(self):
        """ Create a step mirror; it will mirror all of the special steps required to re-implement the Aldebaran walk engine (ie starting, following and stopping steps) 
        Every step with a filename starting with 'Position' and ending with 'Start' or 'Follow' or 'Stop' in the ./steps/ directory will be opened and mirrored.
        """
        ## firstly we need to find all of the files that need to be mirrored (any file with both Position and (Start or Follow or Stop))            
        self.Filepaths = glob.glob('./steps/Position*Start.csv') + glob.glob('./steps/Position*Follow.csv') + glob.glob('./steps/Position*Stop.csv')
        self.Readers = list()
        for filepath in self.Filepaths:
            self.Readers.append(csv.reader(open(filepath, 'r')))
            
        for reader in self.Readers:             ## remove all of the labels from the csv files, and save at least one of them in self.FileLabels just in case I need it
            self.FileLabels = reader.next()
        
        ## a plot to put gait information on
        self.DataFigure = pylab.figure(figsize=(15,8))
        self.DataAxes = pylab.subplot(1,1,1)
        self.DataAxes.set_title(r'Step Mirror Debug Plot')
        self.DataAxes.set_xlabel(r'Time (s)')
        self.DataAxes.set_ylabel(r'Targets')
        pylab.subplots_adjust(left=0.07,bottom=0.07, right=0.95, top=0.93, wspace=0.2, hspace=0.2)
        
        ## Useful Information don't delete anything below this comment
        ## columns where the relevant data is
        self.LeftArmIndices = [0,1,2,3] 
        self.LeftArmLabels = ['LShoulderRoll','LShoulderPitch','LElbowYaw','LElbowRoll']
        self.RightArmIndices = [4,5,6,7]
        self.LeftArmLabels = ['RShoulderRoll','RShoulderPitch','RElbowYaw','RElbowRoll']

        self.PelvisIndex = [8]
        self.PelvisLabels = ['Pelvis']
        
        self.LeftLegIndices = [9,10,11,12,13]
        self.LeftLegLabels = ['LHipRoll','LHipPitch','LKneePitch','LAnklePitch','LAnkleRoll']
        self.RightLegIndices = [15,16,17,18,19]
        self.RightLegLabels = ['RHipRoll','RHipPitch','RKneePitch','RAnklePitch','RAnkleRoll']
        
        self.Indices = self.LeftArmIndices + self.RightArmIndices + self.LeftLegIndices + self.RightLegIndices + self.PelvisIndex
        
    def run(self):
        """ Run the step mirror baby. 
        All mirrored steps will be saved in the ./steps directory with usual name formating. """
        self.readData()
        self.analyseData()
        self.plotData()
        self.writeData()
        #self.formatFigures()
        
        #pylab.show()
        
    def readData(self):
        """ Read in each step and save it in self.Steps """
        self.Steps = list()     ## this is a list of 2-d numpy arrays, [SingleStepPositions[ith cycle][jth joint], ... , SingleStepPositions[ith cycle][jth joint]]
        for reader in self.Readers:
            self.Steps.append(self.readToArray(reader))
            
                
    def readToArray(self, csvreader):
        """ Returns the data in the csv reader as a 2d numpy array """
        stepdata = list()
        for row in csvreader:
            self.addRow(row, stepdata)
        return numpy.array(stepdata)
        
                
    def addRow(self, row, stepdata):
        """ Add a row of data to the list. """
        if len(row) < len(self.FileLabels) - 1:
            return
        
        ## create a new row in the 2-d array
        stepdata.append(list())
            
        ## add each column to the new row
        for col in row:
            try:
                stepdata[-1].append(float(col))
            except:
                pass
                
    def analyseData(self):
        """ Analyses each step and creates a mirrored version.
        The mirrored steps are stored in self.MirroredSteps. """
        self.MirroredSteps = list()
        for step in self.Steps:
            self.MirroredSteps.append(self.produceMirror(step))
        
    def produceMirror(self, stepdata):
        """ Returns the mirror of a single step """
        mirroredstep = numpy.zeros(stepdata.shape)
        for row,mirrorrow in zip(stepdata, mirroredstep):
            ## The pitch joints transfer left to right without change, the roll and yaw joints need to have their polarity switch
            ## do the left arm
            mirrorrow[0] = -row[4]
            mirrorrow[1] = row[5]
            mirrorrow[2] = -row[6]
            mirrorrow[3] = -row[7]
            ## do the right arm
            mirrorrow[4] = -row[0]
            mirrorrow[5] = row[1]
            mirrorrow[6] = -row[2]
            mirrorrow[7] = -row[3]

            ## don't need to mirror the pelvis
            mirrorrow[8] = row[8]
            mirrorrow[14] = row[14]
            
            ## do the left leg
            mirrorrow[9] = -row[15]         ## LHipRoll = -RHipRoll
            mirrorrow[10] = row[16]         ## LHipPitch = RHipPitch
            mirrorrow[11] = row[17]         ## LKneePitch = RKneePitch
            mirrorrow[12] = row[18]         ## LAnklePitch = RAnklePitch
            mirrorrow[13] = -row[19]        ## LAnkleRoll = -RAnkleRoll
            
            ## do the right leg
            mirrorrow[15] = -row[9]         ## RHipRoll = -LHipRoll
            mirrorrow[16] = row[10]         ## RHipPitch = LHipPitch
            mirrorrow[17] = row[11]         ## RKneePitch = LKneePitch
            mirrorrow[18] = row[12]         ## RAnklePitch = LAnklePitch
            mirrorrow[19] = -row[13]        ## RAnkleRoll = -LAnkleRoll
        return mirroredstep
                                
                
    def plotData(self):
        """
        """
        ## I want to plot each step one after the other, so I need to create a single list with all of the steps in it
        allsteps = list()
        for step in self.Steps:
            for frame in step:
                allsteps.append(frame)
        self.DataAxes.plot(allsteps)
        allmirrors = list()
        for step in self.MirroredSteps:
            for frame in step:
                allmirrors.append(frame-3)              ## I am going to shift the step down so I can see it fool :D
        self.DataAxes.plot(allmirrors)
        
    def writeData(self):
        """ """
        ## Now I need to get the names of the mirrored steps; just replace the last 'Left' or 'Right' with 'Right' or 'Left'
        left = ('LeftStart.csv','LeftFollow.csv','LeftStop.csv')
        right = ('RightStart.csv','RightFollow.csv','RightStop.csv')
        self.MirrorFilepaths = list()
        for filepath in self.Filepaths:
            for l,r in zip(left, right):
                if filepath.endswith(l):
                    self.MirrorFilepaths.append(filepath.replace(l, r))
                if filepath.endswith(r):
                    self.MirrorFilepaths.append(filepath.replace(r, l))
        
        ## Now I have the names write the steps to disk :D, that is all
        for filepath,step in zip(self.MirrorFilepaths, self.MirroredSteps):
            writer = csv.writer(open(filepath, 'w'))
            writer.writerow(self.FileLabels)
            writer.writerows(step)
        
         
    def formatFigures(self):
        """
        """
        ## Dataaaaaaa
        ticks = numpy.arange(0, 600 + 100, 100)      ## remember stop is one after the last entry
        labels = [str(tick) for tick in ticks]
        self.DataAxes.set_xticks(ticks)
        self.DataAxes.set_xticklabels(labels, fontsize=10)
        self.DataAxes.set_xlim([ticks[0],ticks[-1]])
        
        ticks = numpy.arange(0, 10 + 1,1)      ## remember stop is one after the last entry
        labels = [str(tick) for tick in ticks]
        self.DataAxes.set_yticks(ticks)
        self.DataAxes.set_yticklabels(labels, fontsize=10)
        self.DataAxes.set_ylim([ticks[0],ticks[-1]])
        

if __name__ == '__main__':
    ##filenames = ['PositionWalkForwardRightStart.csv','PositionWalkForwardLeftStop.csv','PositionWalkForwardLeftFStop.csv']
    mirror = StepMirror()
    mirror.run()
    
    pylab.show()
        
            
            

