""" 

Jason Kulk
"""
import csv, numpy, pylab, matplotlib, os, sys, glob        

if __name__ == '__main__':
    ## get the walk data from the specified NAO
    os.system('rm -r ./steps')
    os.system('rm -r ./poses')
    
    naohost = 'root@' + sys.argv[1] + ':'
    stepssource = naohost + '/home/root/steps'
    stepsdestination = './'
    posesource = naohost + '/home/root/poses'
    posedestination = './'
    os.system('scp -r ' + stepssource + ' ' + stepsdestination)
    os.system('scp -r ' + posesource + ' ' + posedestination)
    
    ## make a back up of the original untouched data in 'originaldata'
    os.system('rm -r originalcapture/*')
    os.system('cp -r ./poses ./originalcapture')
    os.system('cp -r ./steps ./originalcapture')
    
    
        
            
            

