""" 

Jason Kulk
"""
import csv, numpy, pylab, matplotlib, sys
#import rpy

#from Log import Log
#import Common

#pylab.close('all')
#matplotlib.rc('text', usetex=True)

class Plotter:
    """
    """
    
    def __init__(self, filenames):
        """ 
        """
        self.Files = list()                 ## a list of open file objects that contain the data to be analysed
        for filename in filenames:
            self.Files.append(open(filename, 'r'))
        
        self.Readers = list()               ## a list of csv readers, operating on each of the open files
        for file in self.Files:
            self.Readers.append(csv.reader(file))
        
        ## columns where the relevant data is
        self.TimeIndex = 0
        self.LeftArmIndices = [3,4,5,6] 
        self.LeftArmLabels = ['LShoulderRoll','LShoulderPitch','LElbowYaw','LElbowRoll']
        self.RightArmIndices = [7,8,9,10]
        self.RightArmLabels = ['RShoulderRoll','RShoulderPitch','RElbowYaw','RElbowRoll']

        self.PelvisIndex = [11]
        self.PelvisLabels = ['Pelvis']
        
        self.LeftLegIndices = [12,13,14,15,16]
        self.LeftLegLabels = ['LHipRoll','LHipPitch','LKneePitch','LAnklePitch','LAnkleRoll']
        self.RightLegIndices = [18,19,20,21,22]
        self.RightLegLabels = ['RHipRoll','RHipPitch','RKneePitch','RAnklePitch','RAnkleRoll']
        
        self.Indices = self.LeftArmIndices + self.RightArmIndices + self.LeftLegIndices + self.RightLegIndices + self.PelvisIndex
        
        ## create data storage lists
        self.SupportModeTimes = list()
        self.TargetTimes = list()
        self.SupportModes = list()            
        self.LeftArmTargets = list()   
        self.RightArmTargets = list()
        self.LeftLegTargets = list()
        self.RightLegTargets = list()
        self.PelvisTargets = list()
        
        for i in self.LeftArmIndices:
            self.LeftArmTargets.append(list())
        for i in self.RightArmIndices:
            self.RightArmTargets.append(list())
            
        for i in self.LeftLegIndices:
            self.LeftLegTargets.append(list())
        for i in self.RightLegIndices:
            self.RightLegTargets.append(list())
            
        for i in self.PelvisIndex:
            self.PelvisTargets.append(list())
        
        self.DataFigure = pylab.figure(figsize=(15,8))      ## a plot of the PositionDerivatives v Motor Speed Register Values
        self.DataAxes = pylab.subplot(1,1,1)
        self.DataAxes.set_title(r'Walk Plot')
        self.DataAxes.set_xlabel(r'Time (s)')
        self.DataAxes.set_ylabel(r'Targets')
        pylab.subplots_adjust(left=0.07,bottom=0.07, right=0.95, top=0.93, wspace=0.2, hspace=0.2)
        
    def run(self):
        """
        """
        self.readData()
        self.plotData()
        #self.formatFigures()
        
        #pylab.show()
        
    def readData(self):
        """ Read in all of the data.
        Preconditions: we have a csv reader over each data file
        Postconiditons: the lists of the data sequences have the new data appended to them
        """
        reader = self.Readers[0]         ## a reader over target feedback file
        for row in reader:
            self.addTargetRow(row)
            
        reader = self.Readers[1]         ## a reader over support mode feedback file
        for row in reader:
            self.addSupportRow(row)
            
        self.Targets = self.LeftArmTargets + self.RightArmTargets + self.LeftLegTargets + self.RightLegTargets + self.PelvisTargets
                
    def addTargetRow(self, row):
        """
        """
        if len(row) < 23:
            return
            
        try:
            self.TargetTimes.append(float(row[self.TimeIndex]))
        except ValueError:
            return
        
        for i,col in enumerate(self.LeftArmIndices):
            try:
                target = float(row[col])
                self.LeftArmTargets[i].append(target)
            except ValueError:
                pass
                
        for i,col in enumerate(self.RightArmIndices):
            try:
                target = float(row[col])
                self.RightArmTargets[i].append(target)
            except ValueError:
                pass
                
        for i,col in enumerate(self.LeftLegIndices):
            try:
                target = float(row[col])
                self.LeftLegTargets[i].append(target)
            except ValueError:
                pass
                
        for i,col in enumerate(self.RightLegIndices):
            try:
                target = float(row[col])
                self.RightLegTargets[i].append(target)
            except ValueError:
                pass
            
        for i,col in enumerate(self.PelvisIndex):
            try:
                target = float(row[col])
                self.PelvisTargets[i].append(target)
            except ValueError:
                pass    
        
    def addSupportRow(self, row):
        """
        """
        if len(row) < 2:
            return
        try:
            self.SupportModeTimes.append(float(row[0]))
            mode = float(row[1])
            self.SupportModes.append(mode)
        except ValueError:
            pass
            
    def plotData(self):
        """
        """
        for i,targets in enumerate(self.LeftArmTargets):
            self.DataAxes.plot(self.TargetTimes, targets, label=self.LeftArmLabels[i], color = 'g', marker='o')
            
        ##for i,targets in enumerate(self.RightArmTargets):
        ##    self.DataAxes.plot(self.TargetTimes, targets, label=self.RightArmLabels[i], color = 'm', marker='o')
            
        for i,targets in enumerate(self.LeftLegTargets):
            self.DataAxes.plot(self.TargetTimes, targets, label=self.LeftLegLabels[i], marker='o')
            
        ##for i,targets in enumerate(self.RightLegTargets):
        ##    self.DataAxes.plot(self.TargetTimes, targets, label=self.RightLegLabels[i], marker='o')
        
        for i,targets in enumerate(self.PelvisTargets):
            self.DataAxes.plot(self.TargetTimes, targets, label=self.PelvisLabels[i], marker='o')
            
        self.DataAxes.plot(self.SupportModeTimes, numpy.multiply(0.1, self.SupportModes), label='Support Modes', marker='o')
        
        self.DataAxes.legend()
            
         
    def formatFigures(self):
        """
        """
        ## Dataaaaaaa
        ticks = numpy.arange(0, 600 + 100, 100)      ## remember stop is one after the last entry
        labels = [str(tick) for tick in ticks]
        self.DataAxes.set_xticks(ticks)
        self.DataAxes.set_xticklabels(labels, fontsize=10)
        self.DataAxes.set_xlim([ticks[0],ticks[-1]])
        
        ticks = numpy.arange(0, 10 + 1,1)      ## remember stop is one after the last entry
        labels = [str(tick) for tick in ticks]
        self.DataAxes.set_yticks(ticks)
        self.DataAxes.set_yticklabels(labels, fontsize=10)
        self.DataAxes.set_ylim([ticks[0],ticks[-1]])
        

if __name__ == '__main__':
    ## a list of filenames for each of the motors tested, it is assumed this script is run in the same folder as the listed files
    filenames = ['jointVelocities.csv','jason.log']
    
    plotter = Plotter(filenames)
    plotter.run()
    
    pylab.show()
        
            
            

