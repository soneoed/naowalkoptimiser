""" 

Jason Kulk
"""
import csv, numpy, pylab, matplotlib, sys, glob, os.path

class StepHardness:
    """
    """
    
    def __init__(self):
        """ Create a class that will create blank/default hardness files for each step.
        I will be careful to not overright existing files
        """
        ## firstly we need to get all of the step names
        self.ForwardPaths = list()
        self.BackwardPaths = list()
        self.ArcPaths = list()
        self.SidewardPaths = list()
        self.TurnPaths = list()
        
        self.__getFilePaths(self.ForwardPaths, 'WalkForward')
        self.__getFilePaths(self.BackwardPaths, 'WalkBackward')
        self.__getFilePaths(self.ArcPaths, 'WalkArc')
        self.__getFilePaths(self.SidewardPaths, 'WalkSideward')
        self.__getFilePaths(self.TurnPaths, 'WalkTurn')
        
        self.StepPaths = self.ForwardPaths, self.BackwardPaths, self.ArcPaths, self.SidewardPaths, self.TurnPaths
        
        self.__makeHardnessFilePaths()
        
        self.ForwardHardnessesPaths, self.BackwardHardnessesPaths, self.ArcHardnessesPaths, self.SidewardHardnessesPaths, self.TurnHardnessesPaths = self.HardnessPaths
        
        ## now I need to get the the labels and the length from each of the steps, so I do need to read the files
        self.StepReaders = list()
        for filepaths in self.StepPaths:
            self.StepReaders.append(list())
            for filepath in filepaths:
                self.StepReaders[-1].append(csv.reader(open(filepath, 'r')))
            
        for readers in self.StepReaders:             ## remove all of the labels from the csv files, and save at least one of them in self.FileLabels just in case I need it
            for reader in readers:
                self.FileLabels = reader.next()
                                                
        self.ForwardHardnesses = numpy.array([  0.10, 0.25, 0.10, 0.25,                 ## 'LShoulderRoll','LShoulderPitch','LElbowYaw','LElbowRoll'
                                                0.10, 0.25, 0.10, 0.25,                 ## 'RShoulderRoll','RShoulderPitch','RElbowYaw','RElbowRoll'
                                                0.70, 0.26, 0.55, 0.25, 0.24, 0.28,     ## 'Pelvis','LHipRoll','LHipPitch','LKneePitch','LAnklePitch','LAnkleRoll'
                                                0.70, 0.26, 0.55, 0.25, 0.24, 0.28])    ## 'Pelvis','RHipRoll','RHipPitch','RKneePitch','RAnklePitch','RAnkleRoll'
                                                
        self.BackwardHardnesses = numpy.array([  0.10, 0.25, 0.10, 0.25,                 ## 'LShoulderRoll','LShoulderPitch','LElbowYaw','LElbowRoll'
                                                0.10, 0.25, 0.10, 0.25,                 ## 'RShoulderRoll','RShoulderPitch','RElbowYaw','RElbowRoll'
                                                0.70, 0.26, 0.55, 0.25, 0.23, 0.25,     ## 'Pelvis','LHipRoll','LHipPitch','LKneePitch','LAnklePitch','LAnkleRoll'
                                                0.70, 0.26, 0.55, 0.25, 0.23, 0.25])    ## 'Pelvis','RHipRoll','RHipPitch','RKneePitch','RAnklePitch','RAnkleRoll'
                                                
        self.ArcHardnesses =     numpy.array([  0.10, 0.25, 0.10, 0.25,                 ## 'LShoulderRoll','LShoulderPitch','LElbowYaw','LElbowRoll'
                                                0.10, 0.25, 0.10, 0.25,                 ## 'RShoulderRoll','RShoulderPitch','RElbowYaw','RElbowRoll'
                                                0.70, 0.26, 0.55, 0.25, 0.23, 0.25,     ## 'Pelvis','LHipRoll','LHipPitch','LKneePitch','LAnklePitch','LAnkleRoll'
                                                0.70, 0.26, 0.55, 0.25, 0.23, 0.25])    ## 'Pelvis','RHipRoll','RHipPitch','RKneePitch','RAnklePitch','RAnkleRoll'
                                                
        self.SidewardHardnesses =   numpy.array([  0.10, 0.25, 0.10, 0.25,                 ## 'LShoulderRoll','LShoulderPitch','LElbowYaw','LElbowRoll'
                                                   0.10, 0.25, 0.10, 0.25,                 ## 'RShoulderRoll','RShoulderPitch','RElbowYaw','RElbowRoll'
                                                   0.70, 0.35, 0.55, 0.25, 0.23, 0.25,     ## 'Pelvis','LHipRoll','LHipPitch','LKneePitch','LAnklePitch','LAnkleRoll'
                                                   0.70, 0.35, 0.55, 0.25, 0.23, 0.25])    ## 'Pelvis','RHipRoll','RHipPitch','RKneePitch','RAnklePitch','RAnkleRoll'
                                                   
        self.TurnHardnesses = numpy.array([  0.10, 0.25, 0.10, 0.25,                 ## 'LShoulderRoll','LShoulderPitch','LElbowYaw','LElbowRoll'
                                                0.10, 0.25, 0.10, 0.25,                 ## 'RShoulderRoll','RShoulderPitch','RElbowYaw','RElbowRoll'
                                                0.70, 0.26, 0.55, 0.25, 0.23, 0.25,     ## 'Pelvis','LHipRoll','LHipPitch','LKneePitch','LAnklePitch','LAnkleRoll'
                                                0.70, 0.26, 0.55, 0.25, 0.23, 0.25])    ## 'Pelvis','RHipRoll','RHipPitch','RKneePitch','RAnklePitch','RAnkleRoll'
                                                
        print "Forward Hardnesses:", self.ForwardHardnesses
        print "Backward Hardnesses:", self.BackwardHardnesses
        print "Arc Hardnesses:", self.ArcHardnesses
        print "SidewardHardnesses:", self.SidewardHardnesses
        self.StepPositions = list()     ## this is a list of 2-d numpy arrays, [SingleStepPositions[ith cycle][jth joint], ... , SingleStepPositions[ith cycle][jth joint]]
        self.StepHardnesses = list()
        
        
        
        ## Useful Information don't delete anything below this comment
        ## columns where the relevant data is
        self.LeftArmIndices = [0,1,2,3] 
        self.LeftArmLabels = ['LShoulderRoll','LShoulderPitch','LElbowYaw','LElbowRoll']
        self.RightArmIndices = [4,5,6,7]
        self.LeftArmLabels = ['RShoulderRoll','RShoulderPitch','RElbowYaw','RElbowRoll']

        self.PelvisIndex = [8]
        self.PelvisLabels = ['Pelvis']
        
        self.LeftLegIndices = [9,10,11,12,13]
        self.LeftLegLabels = ['LHipRoll','LHipPitch','LKneePitch','LAnklePitch','LAnkleRoll']
        self.RightLegIndices = [15,16,17,18,19]
        self.RightLegLabels = ['RHipRoll','RHipPitch','RKneePitch','RAnklePitch','RAnkleRoll']
        
        self.Indices = self.LeftArmIndices + self.RightArmIndices + self.LeftLegIndices + self.RightLegIndices + self.PelvisIndex
        
    def __getFilePaths(self, pathlist, walktypename):
        """
        """
        validfileendings = 'Left.csv', 'Right.csv', 'Start.csv', 'Follow.csv', 'FStop.csv', 'NStop.csv'

        for ending in validfileendings:
            paths = glob.glob('./steps/Position' + walktypename + '*' + ending)
            for path in paths:
                pathlist.append(path)
                
    def __makeHardnessFilePaths(self):
        """
        """
        hardnesspaths = list()
        for filepaths in self.StepPaths:
            hardnesspaths.append(list())
            for filepath in filepaths:
                hardnesspaths[-1].append(filepath.replace('Position', 'Hardness'))
        
        ## now remove any hardness file that already exists
        self.HardnessPaths = list()
        for filepaths in hardnesspaths:
            self.HardnessPaths.append(list())
            for filepath in filepaths:
                if os.path.exists(filepath):
                    print "WARNING:", filepath, "already exists"
                else:
                    self.HardnessPaths[-1].append(filepath)
        
    def run(self):
        """ Run the default step hardness file creator. """
        self.readData()
        self.analyseData()
        self.writeData()
        #self.formatFigures()
        
        #pylab.show()
        
    def readData(self):
        """ Read in each step and save it in self.StepPositions """
        for readers in self.StepReaders:
            self.StepPositions.append(list())
            for reader in readers:
                self.StepPositions[-1].append(self.readToArray(reader))
        
        self.ForwardStepPositions, self.BackwardStepPositions, self.ArcStepPositions, self.SidewardStepPositions, self.TurnStepPositions = self.StepPositions
            
                
    def readToArray(self, csvreader):
        """ Returns the data in the csv reader as a 2d numpy array """
        stepdata = list()
        for row in csvreader:
            self.addRow(row, stepdata)
        return numpy.array(stepdata)
        
                
    def addRow(self, row, stepdata):
        """ Add a row of data to the list. """
        if len(row) < len(self.FileLabels) - 1:
            return
        
        ## create a new row in the 2-d array
        stepdata.append(list())
            
        ## add each column to the new row
        for col in row:
            try:
                stepdata[-1].append(float(col))
            except:
                pass
                
    def analyseData(self):
        """ . """
        self.__generateHardness(self.ForwardStepPositions, self.ForwardHardnesses)
        self.__generateHardness(self.BackwardStepPositions, self.BackwardHardnesses)
        self.__generateHardness(self.ArcStepPositions, self.ArcHardnesses)
        self.__generateHardness(self.SidewardStepPositions, self.SidewardHardnesses)
        self.__generateHardness(self.TurnStepPositions, self.TurnHardnesses)
            
    def __generateHardness(self, steppositions, defaulthardnesses):
        """
        """
        self.StepHardnesses.append(list())
        for step in steppositions:
            hardness = numpy.zeros(step.shape)
            for i in range(0, len(step)):
                hardness[i] = defaulthardnesses
            self.StepHardnesses[-1].append(hardness)
        
    def writeData(self):
        """ """
        for filepaths,hardnesses in zip(self.HardnessPaths, self.StepHardnesses):
            for filepath, hardness in zip(filepaths, hardnesses):
                writer = csv.writer(open(filepath, 'w'))
                writer.writerow(self.FileLabels)
                writer.writerows(hardness)
        
         
    def formatFigures(self):
        """
        """
        ## Dataaaaaaa
        ticks = numpy.arange(0, 600 + 100, 100)      ## remember stop is one after the last entry
        labels = [str(tick) for tick in ticks]
        self.DataAxes.set_xticks(ticks)
        self.DataAxes.set_xticklabels(labels, fontsize=10)
        self.DataAxes.set_xlim([ticks[0],ticks[-1]])
        
        ticks = numpy.arange(0, 10 + 1,1)      ## remember stop is one after the last entry
        labels = [str(tick) for tick in ticks]
        self.DataAxes.set_yticks(ticks)
        self.DataAxes.set_yticklabels(labels, fontsize=10)
        self.DataAxes.set_ylim([ticks[0],ticks[-1]])
        

if __name__ == '__main__':
    hardness = StepHardness()
    hardness.run()
        
            
            

