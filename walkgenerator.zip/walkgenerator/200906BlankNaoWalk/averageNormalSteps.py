""" 

Jason Kulk
"""
import csv, numpy, pylab, matplotlib, sys, glob
        

class StepAverager:
    """
    """
    
    def __init__(self):
        """ Create a step averager to combined the numerous steps into a perfect one. Will also make sure the steps are all the same """
        ## I group all files that have the same name except the final number; I do this by looking at those with '.0csv' at the end, and then using that for path expansion
        basepaths = glob.glob('./steps/Position*0.csv')
        pathpatterns = list()
        for base in basepaths:
            pathpatterns.append(base.replace('0.csv','[0-9].csv'))
        self.StepPaths = list()
        for pattern in pathpatterns:
            self.StepPaths.append(glob.glob(pattern))
        
        self.StepNames = list()         ## the name of each step group
        for base in basepaths:
            self.StepNames.append(base.replace('0.csv','.csv'))
        
        ## Now get a reader over each file; keep the readers grouped as well
        self.StepReaders = list()
        for pathgroup in self.StepPaths:
            self.StepReaders.append(list())
            for filepath in pathgroup:
                self.StepReaders[-1].append(csv.reader(open(filepath, 'r')))
            
        for readergroup in self.StepReaders:             ## remove all of the labels from the csv files, and save at least one of them in self.FileLabels just in case I need it
            for reader in readergroup:
                self.FileLabels = reader.next()
            
        self.Steps = list()                         ## all of the steps, potentially in no particular order
        self.StepAverages = list()                  ## all of the averaged steps
        
        ## a plot to put gait information on
        self.DataFigure = pylab.figure(figsize=(15,8))
        self.DataAxes = pylab.subplot(1,1,1)
        self.DataAxes.set_title(r'Step Average Debug Plot')
        self.DataAxes.set_xlabel(r'Cycle (units)')
        self.DataAxes.set_ylabel(r'Targets')
        pylab.subplots_adjust(left=0.07,bottom=0.07, right=0.95, top=0.93, wspace=0.2, hspace=0.2)
        
        ## Useful Information don't delete anything below this comment
        ## columns where the relevant data is
        self.LeftArmIndices = [0,1,2,3] 
        self.LeftArmLabels = ['LShoulderRoll','LShoulderPitch','LElbowYaw','LElbowRoll']
        self.RightArmIndices = [4,5,6,7]
        self.LeftArmLabels = ['RShoulderRoll','RShoulderPitch','RElbowYaw','RElbowRoll']

        self.PelvisIndex = [8]
        self.PelvisLabels = ['Pelvis']
        
        self.LeftLegIndices = [9,10,11,12,13]
        self.LeftLegLabels = ['LHipRoll','LHipPitch','LKneePitch','LAnklePitch','LAnkleRoll']
        self.RightLegIndices = [15,16,17,18,19]
        self.RightLegLabels = ['RHipRoll','RHipPitch','RKneePitch','RAnklePitch','RAnkleRoll']
        
        self.Indices = self.LeftArmIndices + self.RightArmIndices + self.LeftLegIndices + self.RightLegIndices + self.PelvisIndex
        
    def run(self):
        """ Run the step averager """
        for readergroup in self.StepReaders:
            self.Steps.append(list())
            self.readData(readergroup, self.Steps[-1])

        self.analyseData()
        self.plotData()
        self.writeData()
        #self.formatFigures()
        
        #pylab.show()
        
    def readData(self, csvreaders, steps):
        """ Read in each almotion stopping step and save it in self.StoppingSteps """ 
        for i,reader in enumerate(csvreaders):
            steps.append(self.readToArray(reader))
            
                
    def readToArray(self, csvreader):
        """ Returns the data in the csv reader as a 2d numpy array """
        stepdata = list()
        for row in csvreader:
            self.addRow(row, stepdata)
        return numpy.array(stepdata)
        
                
    def addRow(self, row, stepdata):
        """ Add a row of data to the list. """
        if len(row) < len(self.FileLabels) - 1:
            return
        
        ## create a new row in the 2-d array
        stepdata.append(list())
            
        ## add each column to the new row
        for col in row:
            try:
                stepdata[-1].append(float(col))
            except:
                pass
                
    def analyseData(self):
        """ """
        ## I want the average for each stepgroup
        for stepgroup in self.Steps:
            numsteps = 0
            stepshape = self.getMaxShape(stepgroup)
            stepaverage = numpy.zeros(stepshape)
            for i in range(0,len(stepgroup)):
                if stepgroup[i].shape[0] == stepshape[0] and stepgroup[i].shape[1] == stepshape[1]:             ## ignore all steps that have too few frames
                    numsteps += 1
                    stepaverage += stepgroup[i]
            stepaverage /= numsteps
            self.StepAverages.append(stepaverage)
        
        ## I also want to compare each step in a primitive group to make sure they are all pretty much the same
        ## So compare each step to the group average
        for stepgroup, stepaverage, name in zip(self.Steps, self.StepAverages, self.StepNames):
            for step in stepgroup:
                if step.shape == stepaverage.shape:             ## ignore all steps that have too few frames
                    if not numpy.allclose(step, stepaverage, 0, 0.03):
                        print name, ":Not all close"
        
    def getMaxShape(self, stepgroup):
        """ Returns the maximum shape of steps in the step group.
        I have noticed that the number of frames in each step is not always the same; occasionally there is a frame missing!
        So, I need to scrap steps with too few frames """
        maxshape = [0,0]
        for step in stepgroup:
            if step.shape[0] > maxshape[0]:
                maxshape[0] = step.shape[0]
            if step.shape[1] > maxshape[1]:
                maxshape[1] = step.shape[1]
        return maxshape
                                        
    def plotData(self):
        """
        """
        ## I want to plot each step one after the other, so I need to create a single list with all of the steps in it
        for i,stepgroup in enumerate(self.Steps):
            for step in stepgroup:
                self.DataAxes.set_color_cycle(['b','g','r','c','m','y','k'])
                self.DataAxes.plot(step - i*5, marker='o')
        
        for i,step in enumerate(self.StepAverages):
            self.DataAxes.set_color_cycle(['b','g','r','c','m','y','k'])
            self.DataAxes.plot(step - i*5, marker='o', linewidth=3)
            
                
    def writeData(self):
        """ """
        for filepath,step in zip(self.StepNames, self.StepAverages):
            writer = csv.writer(open(filepath, 'w'))
            writer.writerow(self.FileLabels)
            writer.writerows(step)
        
         
    def formatFigures(self):
        """
        """
        ## Dataaaaaaa
        ticks = numpy.arange(0, 600 + 100, 100)      ## remember stop is one after the last entry
        labels = [str(tick) for tick in ticks]
        self.DataAxes.set_xticks(ticks)
        self.DataAxes.set_xticklabels(labels, fontsize=10)
        self.DataAxes.set_xlim([ticks[0],ticks[-1]])
        
        ticks = numpy.arange(0, 10 + 1,1)      ## remember stop is one after the last entry
        labels = [str(tick) for tick in ticks]
        self.DataAxes.set_yticks(ticks)
        self.DataAxes.set_yticklabels(labels, fontsize=10)
        self.DataAxes.set_ylim([ticks[0],ticks[-1]])
        

if __name__ == '__main__':
    ##filenames = ['PositionWalkForwardRightStart.csv','PositionWalkForwardLeftStop.csv','PositionWalkForwardLeftFStop.csv']
    average = StepAverager()
    average.run()
    
    pylab.show()
        
            
            

