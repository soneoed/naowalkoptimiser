""" 

Jason Kulk
"""
import csv, numpy, pylab, matplotlib, os, sys, glob        

if __name__ == '__main__':
    ## firstly make a backup of the exported data in jasondataexport
    os.system('rm -r jasondataexport')
    os.system('cp -r jasondata jasondataexport')
    
    ## now compress the directory
    os.system('tar -czf jasondata.tgz ./jasondata')
    
    ## now send it to the NAO
    if len(sys.argv) == 1:      ## if no robot is specified send it to all of them
        NAOs = 'Call.local', 'Flexo.local', 'Rosie,local', 'GIR.local', 'NUbot1.local', 'NUbot2.local', 'NUbot3.local'
    else:                       ## send it to the robot specified
        NAOs = list()
        for i in range(1, len(sys.argv)):
            NAOs.append(sys.argv[i])
    
    for nao in NAOs:
        naohost = 'root@' + nao
        source = './jasondata.tgz'
        destination = naohost + ':/home/root/'
        os.system('scp ' + source + ' ' + destination)
        os.system('ssh ' + naohost + ' rm -r ./jasondata') 
        os.system('ssh ' + naohost + ' tar -xzf jasondata.tgz') 
        os.system('ssh ' + naohost + ' chown -R root:root jasondata') 
    
        
            
            

