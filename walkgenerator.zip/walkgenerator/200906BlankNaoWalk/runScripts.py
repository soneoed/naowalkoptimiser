""" 

Jason Kulk
"""
import csv, numpy, pylab, matplotlib, os, sys, glob        

from generateMirroredSteps import StepMirror
from averageNormalSteps import StepAverager
from generateStoppingSteps import StepStopper
from generateDefaultHardnesses import StepHardness
from copySteps import StepCopier
from verifyjasondata import StepVerify

if __name__ == '__main__':
    os.system('ulimit -n 4000')     ## increase the maximum number of files OS-X will let you have open at one time!

    mirror = StepMirror()
    mirror.run()
    
    average = StepAverager()
    average.run()
    
    stop = StepStopper()
    stop.run()
    
    ## I need an extra script here to patch the FStop steps of (just) arcs
    ## Just need to scan through NStops and pick the one whose first row is the closest to the FStop
    ## then do the usual smoothing
    
    hardness = StepHardness()
    hardness.run()
    
    copy = StepCopier()
    copy.run()
    
    verify = StepVerify()
    verify.run()
    
    pylab.show()
        
            
            

