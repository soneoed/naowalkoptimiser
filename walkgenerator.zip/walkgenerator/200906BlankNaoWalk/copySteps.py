""" 

Jason Kulk
"""
import csv, numpy, pylab, matplotlib, sys, glob, shutil

class StoppingStep:
    def __init__(self):
        """ """
        

class StepCopier:
    """
    """
    
    def __init__(self):
        """ Create a step finisher to essentially copy the generated steps to the final directory. """
        
        self.StepPaths = glob.glob('./steps/Position*Left.csv') + glob.glob('./steps/Position*Right.csv') + glob.glob('./steps/Position*Start.csv') + glob.glob('./steps/Position*Follow.csv') + glob.glob('./steps/Position*FStop.csv') + glob.glob('./steps/Position*NStop.csv')
        self.HardnessPaths = glob.glob('./steps/Hardness*Left.csv') + glob.glob('./steps/Hardness*Right.csv') + glob.glob('./steps/Hardness*Start.csv') + glob.glob('./steps/Hardness*Follow.csv') + glob.glob('./steps/Hardness*FStop.csv') + glob.glob('./steps/Hardness*NStop.csv')
        self.PosePaths = glob.glob('./poses/Pose*Start.csv')
        
        self.NewStepPaths = list()
        self.NewHardnessPaths = list()
        self.NewPosePaths = list()
        
        ## Useful Information don't delete anything below this comment
        ## columns where the relevant data is
        self.LeftArmIndices = [0,1,2,3] 
        self.LeftArmLabels = ['LShoulderRoll','LShoulderPitch','LElbowYaw','LElbowRoll']
        self.RightArmIndices = [4,5,6,7]
        self.LeftArmLabels = ['RShoulderRoll','RShoulderPitch','RElbowYaw','RElbowRoll']

        self.PelvisIndex = [8]
        self.PelvisLabels = ['Pelvis']
        
        self.LeftLegIndices = [9,10,11,12,13]
        self.LeftLegLabels = ['LHipRoll','LHipPitch','LKneePitch','LAnklePitch','LAnkleRoll']
        self.RightLegIndices = [15,16,17,18,19]
        self.RightLegLabels = ['RHipRoll','RHipPitch','RKneePitch','RAnklePitch','RAnkleRoll']
        
        self.Indices = self.LeftArmIndices + self.RightArmIndices + self.LeftLegIndices + self.RightLegIndices + self.PelvisIndex
        
    def run(self):
        """ Its stop stepper time """
        ## I just need to copy everything into ./jasondata/
        for path in self.StepPaths:
            self.NewStepPaths.append(path.replace('./steps','./jasondata'))
        for path in self.HardnessPaths:
            self.NewHardnessPaths.append(path.replace('./steps','./jasondata'))
        for path in self.PosePaths:
            self.NewPosePaths.append(path.replace('./poses','./jasondata'))

        for src, dst in zip(self.StepPaths + self.HardnessPaths + self.PosePaths, self.NewStepPaths + self.NewHardnessPaths + self.NewPosePaths):
            shutil.copy2(src, dst)
        

if __name__ == '__main__':
    copy = StepCopier()
    copy.run()
        
            
            

