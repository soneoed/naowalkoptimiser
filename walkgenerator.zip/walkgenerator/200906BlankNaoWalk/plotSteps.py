""" 

Jason Kulk
"""
import csv, numpy, pylab, matplotlib, sys
#import rpy

#from Log import Log
#import Common

#pylab.close('all')
#matplotlib.rc('text', usetex=True)

class Plotter:
    """
    """
    
    def __init__(self, filenames):
        """ 
        """
        self.Files = list()                 ## a list of open file objects that contain the data to be analysed
        for filename in filenames:
            self.Files.append(open('steps/' + filename, 'r'))
        
        self.Readers = list()               ## a list of csv readers, operating on each of the open files
        for file in self.Files:
            self.Readers.append(csv.reader(file))
        
        ## columns where the relevant data is
        self.LeftArmIndices = [0,1,2,3] 
        self.LeftArmLabels = ['LShoulderRoll','LShoulderPitch','LElbowYaw','LElbowRoll']
        self.RightArmIndices = [4,5,6,7]
        self.LeftArmLabels = ['RShoulderRoll','RShoulderPitch','RElbowYaw','RElbowRoll']

        self.PelvisIndex = [8]
        self.PelvisLabels = ['Pelvis']
        
        self.LeftLegIndices = [9,10,11,12,13]
        self.LeftLegLabels = ['LHipRoll','LHipPitch','LKneePitch','LAnklePitch','LAnkleRoll']
        self.RightLegIndices = [15,16,17,18,19]
        self.RightLegLabels = ['RHipRoll','RHipPitch','RKneePitch','RAnklePitch','RAnkleRoll']
        
        self.Indices = self.LeftArmIndices + self.RightArmIndices + self.LeftLegIndices + self.RightLegIndices + self.PelvisIndex
        
        ## create data storage lists          
        self.LeftArmTargets = list()   
        self.RightArmTargets = list()
        self.LeftLegTargets = list()
        self.RightLegTargets = list()
        self.PelvisTargets = list()
        
        for i in self.LeftArmIndices:
            self.LeftArmTargets.append(list())
        for i in self.RightArmIndices:
            self.RightArmTargets.append(list())
            
        for i in self.LeftLegIndices:
            self.LeftLegTargets.append(list())
        for i in self.RightLegIndices:
            self.RightLegTargets.append(list())
            
        for i in self.PelvisIndex:
            self.PelvisTargets.append(list())
        
        self.DataFigure = pylab.figure(figsize=(15,8))      ## a plot of the PositionDerivatives v Motor Speed Register Values
        self.DataAxes = pylab.subplot(1,1,1)
        self.DataAxes.set_title(r'Walk Plot')
        self.DataAxes.set_xlabel(r'Time (s)')
        self.DataAxes.set_ylabel(r'Targets')
        pylab.subplots_adjust(left=0.07,bottom=0.07, right=0.95, top=0.93, wspace=0.2, hspace=0.2)
        
    def run(self):
        """
        """
        self.readData()
        self.plotData()
        #self.formatFigures()
        
        #pylab.show()
        
    def readData(self):
        """ Read in all of the data.
        Preconditions: we have a csv reader over each data file
        Postconiditons: the lists of the data sequences have the new data appended to them
        """
        for reader in self.Readers:         ## a reader over target feedback file
            for row in reader:
                self.addTargetRow(row)
            
            
        self.Targets = self.LeftArmTargets + self.RightArmTargets + self.LeftLegTargets + self.RightLegTargets + self.PelvisTargets
                
    def addTargetRow(self, row):
        """
        """
        if len(row) < 20:
            return
            
        
        ## add left arm targets
        for i,col in enumerate(self.LeftArmIndices):
            try:
                target = float(row[col])
                self.LeftArmTargets[i].append(target)
            except ValueError:
                pass
        
        ## add right arm targets
        for i,col in enumerate(self.RightArmIndices):
            try:
                target = float(row[col])
                self.RightArmTargets[i].append(target)
            except ValueError:
                pass
                
        ## add left leg targets
        for i,col in enumerate(self.LeftLegIndices):
            try:
                target = float(row[col])
                self.LeftLegTargets[i].append(target)
            except ValueError:
                pass
                
        ## add right leg targets
        for i,col in enumerate(self.RightLegIndices):
            try:
                target = float(row[col])
                self.RightLegTargets[i].append(target)
            except ValueError:
                pass
        
        ## add the pelvis
        for i,col in enumerate(self.PelvisIndex):
            try:
                target = float(row[col])
                self.PelvisTargets[i].append(target)
            except ValueError:
                pass    
        
    def plotData(self):
        """
        """
        ##for i,targets in enumerate(self.LeftArmTargets):
        ##    self.DataAxes.plot(self.TargetTimes, targets, label=self.LeftArmLabels[i], color = 'g', marker='o')
            
        ##for i,targets in enumerate(self.RightArmTargets):
        ##    self.DataAxes.plot(self.TargetTimes, targets, label=self.RightArmLabels[i], color = 'm', marker='o')
            
        for i,targets in enumerate(self.LeftLegTargets):
            self.DataAxes.plot(targets, label=self.LeftLegLabels[i], marker='o')
            
        for i,targets in enumerate(self.RightLegTargets):
            self.DataAxes.plot(targets, label=self.RightLegLabels[i], marker='o')
        
        for i,targets in enumerate(self.PelvisTargets):
            self.DataAxes.plot(targets, label=self.PelvisLabels[i], marker='o')
        
        self.DataAxes.legend()
            
         
    def formatFigures(self):
        """
        """
        ## Dataaaaaaa
        ticks = numpy.arange(0, 600 + 100, 100)      ## remember stop is one after the last entry
        labels = [str(tick) for tick in ticks]
        self.DataAxes.set_xticks(ticks)
        self.DataAxes.set_xticklabels(labels, fontsize=10)
        self.DataAxes.set_xlim([ticks[0],ticks[-1]])
        
        ticks = numpy.arange(0, 10 + 1,1)      ## remember stop is one after the last entry
        labels = [str(tick) for tick in ticks]
        self.DataAxes.set_yticks(ticks)
        self.DataAxes.set_yticklabels(labels, fontsize=10)
        self.DataAxes.set_ylim([ticks[0],ticks[-1]])
        

if __name__ == '__main__':
    ## a list of each step to be plotted, one after the other
    ## filenames = ['WalkBackwardLeft2.csv','WalkBackwardRight3.csv']
    ## filenames = ['WalkArcLeftRight3.csv','WalkArcLeftLeft4.csv']
    ## filenames = ['WalkArcRightLeft3.csv','WalkArcRightRight4.csv']
    ## filenames = ['WalkSidewardLeftRight2.csv','WalkSidewardLeftLeft3.csv']
    ## filenames = ['WalkSidewardRightLeft2.csv','WalkSidewardRightRight3.csv']
    ## filenames = ['WalkTurnLeftRight2.csv','WalkTurnLeftLeft3.csv']
    filenames = ['PositionWalkForwardRight0.csv','PositionWalkForwardLeft0.csv']
    plotter = Plotter(filenames)
    plotter.run()
    
    pylab.show()
        
            
            

