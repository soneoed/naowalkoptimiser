""" 

Jason Kulk
"""
import glob, csv, numpy, pylab, matplotlib
        
class PoseComparator:

   def __init__(self):
      """ Creates a pose comparator over the files contained in the present working directory """
      self.Filenames = glob.glob('Pose*.csv')
      print self.Filenames
      self.Files = list()                 ## a list of open file objects that contain the data to be analysed
      for filename in self.Filenames:
         self.Files.append(open(filename, 'r'))

      self.Readers = list()               ## a list of csv readers, operating on each of the open files
      for file in self.Files:
         self.Readers.append(csv.reader(file))
         
      self.Poses = list()
      self.Labels = list()

   def run(self):
      """ Runs the comparison """
      ## firstly load all of the poses into memory so that they can be compared
      for reader in self.Readers:
         self.Labels = reader.next()        ## skip the labels
         self.addPose(reader)
      
      ## now we need to compare the poses. The easiest option is to compare all of them to the first one
      self.ComparisonMatrix = numpy.zeros((len(self.Poses),len(self.Poses)))
         
      for j,referencepose in enumerate(self.Poses):
         for i,pose in enumerate(self.Poses):
               print "Comparing", self.Filenames[i], "with", self.Filenames[j]
               self.ComparisonMatrix[i][j] = self.compare(pose, referencepose)
               
      print self.Filenames
      print self.ComparisonMatrix
         
   def addPose(self, reader):
      """ """
      stringpose = reader.next()
      stringpose = stringpose[0:len(stringpose)-1]       ## strip the trailing space
      floatpose = list()
      for string in stringpose:
         floatpose.append(float(string))
      self.Poses.append(floatpose)
      
   def compare(self, pose1, pose2):
      """ """
      result = True
      if len(pose1) != len(pose2):
         print "You have made an error: the poses do not have the same length"
         return False
      else:
         for i in range(0, len(pose1)):
            if (pose1[i] - pose2[i]) > 0.003:
               print "Poses differ by", (pose1[i] - pose2[i]), "on", self.Labels[i]
               result = False
      return result
      
if __name__ == '__main__':
    comparator = PoseComparator()
    comparator.run()    
            
            

