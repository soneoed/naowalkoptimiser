""" 

Jason Kulk
"""
import csv, numpy, pylab, matplotlib, sys, glob

class StoppingStep:
    def __init__(self):
        """ """
        

class StepStopper:
    """
    """
    
    def __init__(self):
        """ Create a step stopper to generate all necessary stopping steps. """
        
        ## Now to generate a stopping step I need (a) the original stopping step (b) the initial pose (c) the starting step
        ## So I want to do for each stopping step:
        self.StoppingStepPaths = glob.glob('./steps/Position*Stop.csv')
        self.StoppingStepReaders = list()
        for filepath in self.StoppingStepPaths:
            self.StoppingStepReaders.append(csv.reader(open(filepath, 'r')))
            
        for reader in self.StoppingStepReaders:             ## remove all of the labels from the csv files, and save at least one of them in self.FileLabels just in case I need it
            self.FileLabels = reader.next()
            
        self.MaximumAcceleration = 100
        self.MaximumEndPoseAcceleration = 20
            
        self.StoppingSteps = list()             ## the original stopping steps made by almotion ;this is a list of 2-d numpy arrays, [SingleStepPositions[ith cycle][jth joint], ... , SingleStepPositions[ith cycle][jth joint]]
        self.FStoppingSteps = list()            ## my stopping steps that follow the starting step 
        self.NStoppingSteps = list()            ## my stopping steps that follow a normal step
        
        ## a plot to put gait information on
        self.DataFigure = pylab.figure(figsize=(15,8))
        self.DataAxes = pylab.subplot(1,1,1)
        self.DataAxes.set_title(r'Step Mirror Debug Plot')
        self.DataAxes.set_xlabel(r'Time (s)')
        self.DataAxes.set_ylabel(r'Targets')
        pylab.subplots_adjust(left=0.07,bottom=0.07, right=0.95, top=0.93, wspace=0.2, hspace=0.2)
        
        ## Useful Information don't delete anything below this comment
        ## columns where the relevant data is
        self.LeftArmIndices = [0,1,2,3] 
        self.LeftArmLabels = ['LShoulderRoll','LShoulderPitch','LElbowYaw','LElbowRoll']
        self.RightArmIndices = [4,5,6,7]
        self.LeftArmLabels = ['RShoulderRoll','RShoulderPitch','RElbowYaw','RElbowRoll']

        self.PelvisIndex = [8]
        self.PelvisLabels = ['Pelvis']
        
        self.LeftLegIndices = [9,10,11,12,13]
        self.LeftLegLabels = ['LHipRoll','LHipPitch','LKneePitch','LAnklePitch','LAnkleRoll']
        self.RightLegIndices = [15,16,17,18,19]
        self.RightLegLabels = ['RHipRoll','RHipPitch','RKneePitch','RAnklePitch','RAnkleRoll']
        
        self.Indices = self.LeftArmIndices + self.RightArmIndices + self.LeftLegIndices + self.RightLegIndices + self.PelvisIndex
        
    def run(self):
        """ Its stop stepper time """
        self.readData(self.StoppingStepReaders, self.StoppingSteps)
        self.analyseData()
        self.plotData()
        self.writeData()
        #self.formatFigures()
        
        #pylab.show()
        
    def readData(self, csvreaders, steps):
        """ Read in each almotion stopping step and save it in self.StoppingSteps """ 
        for i,reader in enumerate(csvreaders):
            steps.append(self.readToArray(reader))
            
                
    def readToArray(self, csvreader):
        """ Returns the data in the csv reader as a 2d numpy array """
        stepdata = list()
        for row in csvreader:
            ##print row
            self.addRow(row, stepdata)
        return numpy.array(stepdata)
        
                
    def addRow(self, row, stepdata):
        """ Add a row of data to the list. """
        if len(row) < len(self.FileLabels) - 1:
            return
        
        ## create a new row in the 2-d array
        stepdata.append(list())
            
        ## add each column to the new row
        for col in row:
            try:
                stepdata[-1].append(float(col))
            except:
                pass
                
    def getStartingSteps(self):
        """ Returns a list of the starting step for each stopping step in self.StoppingSteps """
        readers = list()
        steps = list()
        for stopfilepath in self.StoppingStepPaths:
            if stopfilepath.endswith('LeftStop.csv'):
                startfilepath = stopfilepath.replace('LeftStop','RightStart')
            elif stopfilepath.endswith('RightStop.csv'):
                startfilepath = stopfilepath.replace('RightStop','LeftStart')
            reader = csv.reader(open(startfilepath, 'r'))
            reader.next()           ## skip labels
            readers.append(reader)
        self.readData(readers, steps)
        return steps
        
    def getPoses(self):
        """ Returns a list of initial(/end poses) for each stopping step"""
        readers = list()
        poses = list()
        for stopfilepath in self.StoppingStepPaths:
            posefilepath = stopfilepath.replace('./steps/Position', './poses/Pose')
            if posefilepath.endswith('LeftStop.csv'):
                posefilepath = posefilepath.replace('LeftStop','Start')
            elif posefilepath.endswith('RightStop.csv'):
                posefilepath = posefilepath.replace('RightStop','Start')
            reader = csv.reader(open(posefilepath, 'r'))
            reader.next()           ## skip labels
            readers.append(reader)
        
        for reader in readers:
            data = list()
            self.addRow(reader.next(), data)
            poses.append(numpy.array(data[0]))
        
        return poses
                
    def analyseData(self):
        """ """
        self.StartingSteps = self.getStartingSteps()
        self.Poses = self.getPoses()
        
        ## firstly, generate the FStopping steps
        ## smooth the transistion
        
        ## Now I want to use the stopping step whose first row is the closest to the last row of the starting step 
        ## This is not necessarily from the same walk type
        
        for stepnumber, start in enumerate(self.StartingSteps):
            ## so I need to find the first digit in self.StoppingStepPaths[stepnumber]
            firstdigit = 0
            for k in range(0, len(self.StoppingStepPaths[stepnumber])):
                if self.StoppingStepPaths[stepnumber][k].isdigit():
                    firstdigit = k
                    break
            
                        
            ## find the 'matching' stopping step
            minsum = 1000
            matchindex = 0
            for i,stop in enumerate(self.StoppingSteps):
                ## firstly check whether the type and direction are the same
                if self.StoppingStepPaths[stepnumber][0:firstdigit] == self.StoppingStepPaths[i][0:firstdigit]:
                ## then I need to make sure that the steps are both left or both right
                    if (self.StoppingStepPaths[stepnumber].endswith('LeftStop.csv') and self.StoppingStepPaths[i].endswith('LeftStop.csv')) or (self.StoppingStepPaths[stepnumber].endswith('RightStop.csv') and self.StoppingStepPaths[i].endswith('RightStop.csv')):
                        sum = numpy.sum(numpy.fabs(start[len(start) - 1] - stop[0]))          ## I only care about matching the legs
                        if sum < minsum:
                            minsum = sum
                            matchindex = i
            
            #print self.StoppingStepPaths[stepnumber], "matched with", self.StoppingStepPaths[matchindex] 
            self.FStoppingSteps.append(self.smoothTransistion(start, self.StoppingSteps[matchindex], self.MaximumAcceleration))
        
        #for start,stop in zip(self.StartingSteps, self.StoppingSteps):
        #    self.FStoppingSteps.append(self.smoothTransistion(start, stop, self.MaximumAcceleration))
        ## then make the end pose equal to the initial pose
        for i,(pose,stop) in enumerate(zip(self.Poses, self.FStoppingSteps)):
            pose = [pose,pose]
            self.FStoppingSteps[i] = numpy.array(self.smoothTransistion(pose, stop[::-1], self.MaximumEndPoseAcceleration)[::-1])       ## this reverses the array; does the smooth transistion; then reverses it back [::-1] = reverse
        for i in range(0, len(self.FStoppingSteps)):
            shape = self.FStoppingSteps[i].shape
            self.FStoppingSteps[i].resize((shape[0]+1, shape[1]))
            self.FStoppingSteps[i][-1] = self.Poses[i]
        
        ## secondly generate the Nstopping steps
        for i in range(0, len(self.StoppingSteps)):
            pose = [self.Poses[i],self.Poses[i]]
            self.NStoppingSteps.append(numpy.array(self.smoothTransistion(pose, self.StoppingSteps[i][::-1], self.MaximumEndPoseAcceleration)[::-1]))
        for i in range(0, len(self.NStoppingSteps)):
            shape = self.NStoppingSteps[i].shape
            self.NStoppingSteps[i].resize((shape[0]+1, shape[1]))
            self.NStoppingSteps[i][-1] = self.Poses[i]
            
        ## now I add the end pose to the original stopping steps so that I can compare them easily with the new steps because now everything will have the same length :D
        for i in range(0, len(self.StoppingSteps)):
            shape = self.StoppingSteps[i].shape
            self.StoppingSteps[i].resize((shape[0]+1, shape[1]))
            self.StoppingSteps[i][-1] = self.Poses[i]
            
    def smoothTransistion(self, previousstep, step, maxacceleration):
        """ Return a step that has a smooth transistion between steps (a modified version of the second step is returned)"""
        smoothstep = list()
        
        finished = list()                               ## once the smoothed version has reached the original we are finished
        for i in range(0, len(previousstep[0])):        ## so we keep a list for each joint, when each joint is finished the appropriate element in the list is set to true
            finished.append(False)
            
        for i,frame in enumerate(step):                 ## for each frame of data
            smoothstep.append(list())
            for j,joint in enumerate(frame):
                ## we need to be careful when calculating the velocity and acceleration at the transistion between the two steps
                if i == 0:                          
                    l = len(previousstep)
                    currentposition = previousstep[l-1][j]
                    previousposition = previousstep[l-2][j]
                    previouspreviousposition = previousstep[l-3][j]
                elif i == 1:
                    l = len(previousstep)
                    currentposition = smoothstep[i-1][j]
                    previousposition = previousstep[l-1][j]
                    previouspreviousposition = previousstep[l-2][j]
                elif i == 2:
                    l = len(previousstep)
                    currentposition = smoothstep[i-1][j]
                    previousposition = smoothstep[i-2][j]
                    previouspreviousposition = previousstep[l-1][j]
                else:
                    currentposition = smoothstep[i-1][j]
                    previousposition = smoothstep[i-2][j]
                    previouspreviousposition = smoothstep[i-2][j]

                currentvelocity = (currentposition - previousposition)/0.02
                previousvelocity = (previousposition - previouspreviousposition)/0.02
                currentacceleration = (currentvelocity - previousvelocity)/0.02
                
                ## calculate desired acceleration
                nextvelocity = (step[i][j] - currentposition)/0.02          ## this is the velocity I would need to travel to get there
                nextacceleration = 2*(step[i][j] - currentposition - currentvelocity*0.02)/(0.02*0.02)                ## this is the acceleration I would need to travel at to get there
                
                maxa = maxacceleration
                if finished[j] == False:
                    if nextacceleration <= -maxa:
                        ##print "Prefilter:", nextacceleration, nextvelocity, currentposition + currentvelocity*0.02 + 0.5*nextacceleration*0.02*0.02
                        nextacceleration = -maxa                      ## this is the acceleration that I am going to travel at
                        ##nextvelocity = currentvelocity + nextacceleration*0.02                  ## this is the velocity I am going to travel at
                        ##print "Postfiler:", nextacceleration, nextvelocity, currentposition + currentvelocity*0.02 + 0.5*nextacceleration*0.02*0.02
                    elif nextacceleration < maxa:
                        finished[j] = True
                    else:
                        ##print "Prefilter:", nextacceleration, nextvelocity, currentposition + currentvelocity*0.02 + 0.5*nextacceleration*0.02*0.02
                        nextacceleration = maxa                     ## this is the acceleration that I am going to travel at
                        ##nextvelocity = currentvelocity + nextacceleration*0.02                  ## this is the velocity I am going to travel at
                        ##print "Postfiler:", nextacceleration, nextvelocity, currentposition + currentvelocity*0.02 + 0.5*nextacceleration*0.02*0.02
                
                smoothstep[i].append(currentposition + currentvelocity*0.02 + 0.5*nextacceleration*0.02*0.02)

        return numpy.array(smoothstep)
                
    def plotData(self):
        """
        """
        ## I want to plot each step one after the other, so I need to create a single list with all of the steps in it
        presmoothsteps = list()
        postsmoothsteps = list()
        for start,stop,smooth in zip(self.StartingSteps, self.StoppingSteps, self.FStoppingSteps):
            for frame in start:
                presmoothsteps.append(frame)
                postsmoothsteps.append(frame)
            for frame in stop:
                presmoothsteps.append(frame)
            for frame in smooth:
                postsmoothsteps.append(frame)
                
        for stop,smooth in zip(self.StoppingSteps, self.NStoppingSteps):
            for frame in stop:
                presmoothsteps.append(frame)
            for frame in smooth:
                postsmoothsteps.append(frame)
                    
        self.DataAxes.set_color_cycle(['b','g','r','c','m','y','k'])
        self.DataAxes.plot(presmoothsteps)
        self.DataAxes.set_color_cycle(['b','g','r','c','m','y','k'])
        self.DataAxes.plot(postsmoothsteps, linewidth=3, marker='o')
                
    def writeData(self):
        """ """
        ## Now I need to get the names of the stopping steps right; if its an FStop replace 'Stop' with 'FStop', if its an NStop replace 'Stop' with 'NStop'
        self.FStopFilepaths = list()
        for filepath in self.StoppingStepPaths:
            self.FStopFilepaths.append(filepath.replace('Stop', 'FStop'))
        
        self.NStopFilepaths = list()
        for filepath in self.StoppingStepPaths:
            self.NStopFilepaths.append(filepath.replace('Stop', 'NStop'))
        
        ## Now I have the names write the steps to disk :D, that is all
        for filepath,step in zip(self.FStopFilepaths + self.NStopFilepaths, self.FStoppingSteps + self.NStoppingSteps):
            writer = csv.writer(open(filepath, 'w'))
            writer.writerow(self.FileLabels)
            writer.writerows(step)
        
         
    def formatFigures(self):
        """
        """
        ## Dataaaaaaa
        ticks = numpy.arange(0, 600 + 100, 100)      ## remember stop is one after the last entry
        labels = [str(tick) for tick in ticks]
        self.DataAxes.set_xticks(ticks)
        self.DataAxes.set_xticklabels(labels, fontsize=10)
        self.DataAxes.set_xlim([ticks[0],ticks[-1]])
        
        ticks = numpy.arange(0, 10 + 1,1)      ## remember stop is one after the last entry
        labels = [str(tick) for tick in ticks]
        self.DataAxes.set_yticks(ticks)
        self.DataAxes.set_yticklabels(labels, fontsize=10)
        self.DataAxes.set_ylim([ticks[0],ticks[-1]])
        

if __name__ == '__main__':
    ##filenames = ['PositionWalkForwardRightStart.csv','PositionWalkForwardLeftStop.csv','PositionWalkForwardLeftFStop.csv']
    from generateMirroredSteps import StepMirror
    mirror = StepMirror()
    mirror.run()
    
    stop = StepStopper()
    stop.run()
    
    pylab.show()
        
            
            

