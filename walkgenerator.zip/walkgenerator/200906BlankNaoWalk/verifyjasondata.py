""" A Tool to check the validity of jasondata

    Check that no single column is filled with all zeros (this seems to be a common problem)
    Check that each file is about the right length

Jason Kulk
"""
import csv, numpy, pylab, matplotlib, sys, glob

class StepVerify:
    """
    """
    
    def __init__(self):
        """ Create a step verifier
        """
        ## firstly we need to find all of the files that need to be mirrored (any file with both Position and (Start or Follow or Stop))            
        if len(sys.argv) < 2:
            location = './jasondata/'
        else:
            location = sys.argv[1] + '/'
        self.Filepaths = glob.glob(location + 'Position*.csv')     ## read in all step position files
        
        self.Readers = list()
        for filepath in self.Filepaths:
            self.Readers.append(csv.reader(open(filepath, 'r')))
            
        for reader in self.Readers:             ## remove all of the labels from the csv files, and save at least one of them in self.FileLabels just in case I need it
            self.FileLabels = reader.next()
        
        ## a plot to put gait information on
        self.DataFigure = pylab.figure(figsize=(15,8))
        self.DataAxes = pylab.subplot(1,1,1)
        self.DataAxes.set_title(r'Step Mirror Debug Plot')
        self.DataAxes.set_xlabel(r'Time (s)')
        self.DataAxes.set_ylabel(r'Targets')
        pylab.subplots_adjust(left=0.07,bottom=0.07, right=0.95, top=0.93, wspace=0.2, hspace=0.2)
        
        ## Useful Information don't delete anything below this comment
        ## columns where the relevant data is
        self.LeftArmIndices = [0,1,2,3] 
        self.LeftArmLabels = ['LShoulderRoll','LShoulderPitch','LElbowYaw','LElbowRoll']
        self.RightArmIndices = [4,5,6,7]
        self.LeftArmLabels = ['RShoulderRoll','RShoulderPitch','RElbowYaw','RElbowRoll']

        self.PelvisIndex = [8]
        self.PelvisLabels = ['Pelvis']
        
        self.LeftLegIndices = [9,10,11,12,13]
        self.LeftLegLabels = ['LHipRoll','LHipPitch','LKneePitch','LAnklePitch','LAnkleRoll']
        self.RightLegIndices = [15,16,17,18,19]
        self.RightLegLabels = ['RHipRoll','RHipPitch','RKneePitch','RAnklePitch','RAnkleRoll']
        
        self.Indices = self.LeftArmIndices + self.RightArmIndices + self.LeftLegIndices + self.RightLegIndices + self.PelvisIndex
        
    def run(self):
        """ Verify the walk data. 
        Messages will be printed if anything is found to be wrong. """
        self.readData()
        self.analyseData()
        self.plotData()
        #self.formatFigures()
        
        #pylab.show()
        
    def readData(self):
        """ Read in each step and save it in self.Steps """
        self.Steps = list()     ## this is a list of 2-d numpy arrays, [SingleStepPositions[ith cycle][jth joint], ... , SingleStepPositions[ith cycle][jth joint]]
        for reader in self.Readers:
            self.Steps.append(self.readToArray(reader))
            
                
    def readToArray(self, csvreader):
        """ Returns the data in the csv reader as a 2d numpy array """
        stepdata = list()
        for row in csvreader:
            self.addRow(row, stepdata)
        return numpy.array(stepdata)
        
                
    def addRow(self, row, stepdata):
        """ Add a row of data to the list. """
        if len(row) < len(self.FileLabels) - 1:
            return
        
        ## create a new row in the 2-d array
        stepdata.append(list())
            
        ## add each column to the new row
        for col in row:
            try:
                stepdata[-1].append(float(col))
            except:
                pass
                
    def analyseData(self):
        """ Analyses each step and determines whether the file is valid.
        """
        ## firstly, verify the shape
        for i, step in enumerate(self.Steps):
            rows, cols = numpy.shape(step)
            if rows < 18:
                print self.Filepaths[i], "has suspiciously few rows:", rows
            if cols != 20:
                print self.Filepaths[i], "has the incorrect number of joints:", cols, "should be 20"
                
        ## now verify that each column is not filled with all zeros 
        for i, step in enumerate(self.Steps):
            for j in range(0, numpy.shape(step)[1]):
                col = step[:,j]
                if numpy.sum(col) == 0:
                    print self.Filepaths[i], "has a zero column", self.FileLabels[j]
        
        
    def plotData(self):
        """
        """
        
         
    def formatFigures(self):
        """
        """
        ## Dataaaaaaa
        ticks = numpy.arange(0, 600 + 100, 100)      ## remember stop is one after the last entry
        labels = [str(tick) for tick in ticks]
        self.DataAxes.set_xticks(ticks)
        self.DataAxes.set_xticklabels(labels, fontsize=10)
        self.DataAxes.set_xlim([ticks[0],ticks[-1]])
        
        ticks = numpy.arange(0, 10 + 1,1)      ## remember stop is one after the last entry
        labels = [str(tick) for tick in ticks]
        self.DataAxes.set_yticks(ticks)
        self.DataAxes.set_yticklabels(labels, fontsize=10)
        self.DataAxes.set_ylim([ticks[0],ticks[-1]])
        

if __name__ == '__main__':
    ##filenames = ['PositionWalkForwardRightStart.csv','PositionWalkForwardLeftStop.csv','PositionWalkForwardLeftFStop.csv']
    verify = StepVerify()
    verify.run()
    
    ##pylab.show()
        
            
            

